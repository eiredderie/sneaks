﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;
public class Timer : MonoBehaviour
{
    private float timer = 60f;
    public TextMeshProUGUI timerSeconds;
    public GameObject hide;
    public GameObject show;

    // Use this for initialization
    void Start()
    {
        timerSeconds.text = "60";
        timer = 60f;
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        string seconds= timer.ToString("f0");
        timerSeconds.SetText(seconds);
        if (timer <= 0)
        {
            hide.SetActive(false);
            show.SetActive(true);
        }

    }
}
