﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class TimerGo : MonoBehaviour {

    public TextMeshProUGUI gotimerSeconds;
    public GameObject hide;
    public GameObject show;

    public Button food1;
    public Button food2;
    public Button food3;
    public Button food4;
    public Button food5;
    public Button food6;
    public Button food7;
    public Button food8;
    public Button food9;
    public TextMeshProUGUI goresult;
    public GameObject image1;
    public GameObject image2;
    public GameObject image3;
    public GameObject image4;
    public GameObject image5;
    public GameObject image6;
    public GameObject image7;
    public GameObject image8;
    public GameObject image9;


    public GameObject result1;
    public GameObject result2;
    public GameObject result3;
    public GameObject result4;
    public GameObject result5;
    public GameObject result6;
    public GameObject result7;
    public GameObject result8;
    public GameObject result9;


    public GameObject next;

    private float timer = 60f;
    private int mistakes = 0;
    private int correct = 0;

    // Use this for initialization
    void Start()
    {
        MusicPlayer.PlayGameMusic();
        gotimerSeconds.text = "60";
        timer = 60f;
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        string seconds = timer.ToString("f0");
        gotimerSeconds.SetText(seconds);
        if (timer <= 0)
        {
            goresult.text = "Sorry you ran out of time.";
            hide.SetActive(false);
            show.SetActive(true);
            next.SetActive(false);
            MusicPlayer.PlayMenuMusic();
        }
        else if (mistakes>=3)
        {
            goresult.text = "Better luck next time.";
            hide.SetActive(false);
            show.SetActive(true);
            next.SetActive(false);
            MusicPlayer.PlayMenuMusic();
        }
        else if (correct >= 5)
        {
            switch (mistakes)
            {
                case 1:
                    goresult.text = "Very Good!";
                    break;
                case 2:
                    goresult.text = "Cool!";
                    break;
                default:
                    goresult.text = "Excellent!";
                    break;
            }
            hide.SetActive(false);
            next.SetActive(true);
            MusicPlayer.PlayMenuMusic();
            show.SetActive(true);
        }

    }

    public void Again()
    {
        timer = 60f;
        gotimerSeconds.text = "60";
        correct = 0;
        mistakes = 0;
       
        food1.interactable = true;
        food2.interactable = true;
        food3.interactable = true;
        food4.interactable = true;
        food5.interactable = true;
        food6.interactable = true;
        food7.interactable = true;
        food8.interactable = true;
        food9.interactable = true;
        image1.GetComponent<Image>().color = new Color32(255, 255, 225, 255);
        image2.GetComponent<Image>().color = new Color32(255, 255, 225, 255);
        image3.GetComponent<Image>().color = new Color32(255, 255, 225, 255);
        image4.GetComponent<Image>().color = new Color32(255, 255, 225, 255);
        image5.GetComponent<Image>().color = new Color32(255, 255, 225, 255);
        image6.GetComponent<Image>().color = new Color32(255, 255, 225, 255);
        image7.GetComponent<Image>().color = new Color32(255, 255, 225, 255);
        image8.GetComponent<Image>().color = new Color32(255, 255, 225, 255);
        image9.GetComponent<Image>().color = new Color32(255, 255, 225, 255);

        result1.SetActive(false);
        result2.SetActive(false);
        result3.SetActive(false);
        result4.SetActive(false);
        result5.SetActive(false);
        result6.SetActive(false);
        result7.SetActive(false);
        result8.SetActive(false);
        result9.SetActive(false);

    }



    public void checkFood1()
    {
        mistakes += 1;
        result1.SetActive(true);
        food1.interactable = false;
        image1.GetComponent<Image>().color = new Color32(255, 255, 225, 100);
    }
    public void checkFood2()
    {
        mistakes += 1;
        result2.SetActive(true);
        food2.interactable = false;
        image2.GetComponent<Image>().color = new Color32(255, 255, 225, 100);
    }
    public void checkFood3()
    {
        mistakes += 1;
        result3.SetActive(true);
        food3.interactable = false;
        image3.GetComponent<Image>().color = new Color32(255, 255, 225, 100);
    }
    public void checkFood4()
    {
        mistakes += 1;
        result4.SetActive(true);
        food4.interactable = false;
        image4.GetComponent<Image>().color = new Color32(255, 255, 225, 100);
    }
    public void checkFood5()
    {
        correct += 1;
        result5.SetActive(true);
        food5.interactable = false;
        image5.GetComponent<Image>().color = new Color32(255, 255, 225, 100);
    }
    public void checkFood6()
    {
        correct += 1;
        result6.SetActive(true);
        food6.interactable = false;
        image6.GetComponent<Image>().color = new Color32(255, 255, 225, 100);
    }
    public void checkFood7()
    {
        correct += 1;
        result7.SetActive(true);
        food7.interactable = false;
        image7.GetComponent<Image>().color = new Color32(255, 255, 225, 100);
    }
    public void checkFood8()
    {
        correct += 1;
        result8.SetActive(true);
        food8.interactable = false;
        image8.GetComponent<Image>().color = new Color32(255, 255, 225, 100);
    }
    public void checkFood9()
    {
        correct += 1;
        result9.SetActive(true);
        food9.interactable = false;
        image9.GetComponent<Image>().color = new Color32(255, 255, 225, 100);
    }
}
