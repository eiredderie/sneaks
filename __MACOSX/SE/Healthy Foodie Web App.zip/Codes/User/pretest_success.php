<?php

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		


  $conn = new mysqli ($servername, $username, $password, $dbName);
  if(!$conn){
      die("Connection Failed. ".mysqli_connect_error);
  }
session_start();
  $id=$_SESSION['id'];
  $ans=[];
  $remarks1="Nice";
  $remarks2="Nice";
  $remarks3="Nice";
  $_SESSION['q_no']=0;
  for($i = 1; $i <= 70; $i++) {
    if (isset($_SESSION['prq'.$i])) {
      $ans[]=$_SESSION['prq'.$i];
    }
    else{
      $ans[]="X";
    }
  }

  $tot1=0;
  for($i = 0; $i < 10; $i++) {
      if($ans[$i]!="X")
            $tot1+=$ans[$i];
  }
  $tot2=0;
  for($i = 10; $i < 40; $i++) {
      if($ans[$i]!="X")
            $tot2+=$ans[$i];
  }
  $tot3=0;
  for($i = 40; $i < 70; $i++) {
    if($ans[$i]!="X")
        $tot3+=$ans[$i];
  }

  $total=$tot1+$tot2+$tot3;
  if($tot1==5)
    $remarks1="Excellent";
  elseif ($tot1>3) 
    $remarks1="Very Good";
  elseif ($tot1>1) 
    $remarks1="Good";

  if($tot2==10)
    $remarks2="Excellent";
  elseif ($tot2>6) 
    $remarks2="Very Good";
  elseif ($tot2>3) 
    $remarks2="Good";

  if($tot3==10)
    $remarks3="Excellent";
  elseif ($tot3>6) 
    $remarks3="Very Good";
  elseif ($tot3>3) 
    $remarks3="Good";

  
  $sql = "INSERT INTO pretestq1 (PretestQ1ID, Pr1,Pr2,Pr3,Pr4,Pr5,Pr6,Pr7,Pr8,Pr9,Pr10, Total, Remarks) 
        VALUES ('".$id."',
        '".$ans[0]."','".$ans[1]."','".$ans[2]."','".$ans[3]."','".$ans[4]."','".$ans[5]."','".$ans[6]."','".$ans[7]."','".$ans[8]."','".$ans[9]."',
        '".$tot1."','".$remarks1."')";
  $result = mysqli_query($conn ,$sql);

	
	$conn = new mysqli ($servername, $username, $password, $dbName);
  $sql = "INSERT INTO pretestq2 (PretestQ2ID, Pr11,Pr12,Pr13,Pr14,Pr15,Pr16,Pr17,Pr18,Pr19,Pr20,Pr21,Pr22,Pr23,Pr24,Pr25,Pr26,Pr27,Pr28,Pr29,Pr30,
				Pr31,Pr32,Pr33,Pr34,Pr35,Pr36,Pr37,Pr38,Pr39,Pr40, Total, Remarks) 
        VALUES ('".$id."',
        '".$ans[10]."','".$ans[11]."','".$ans[12]."','".$ans[13]."','".$ans[14]."','".$ans[15]."','".$ans[16]."','".$ans[17]."','".$ans[18]."','".$ans[19]."',
		'".$ans[20]."','".$ans[21]."','".$ans[22]."','".$ans[23]."','".$ans[24]."','".$ans[25]."','".$ans[26]."','".$ans[27]."','".$ans[28]."','".$ans[29]."',
		'".$ans[30]."','".$ans[31]."','".$ans[32]."','".$ans[33]."','".$ans[34]."','".$ans[35]."','".$ans[36]."','".$ans[37]."','".$ans[38]."','".$ans[39]."',
        '".$tot2."','".$remarks2."')";
  $result = mysqli_query($conn ,$sql);
  
  $conn = new mysqli ($servername, $username, $password, $dbName);
  $sql = "INSERT INTO pretestq3 (PretestQ3ID, Pr41,Pr42,Pr43,Pr44,Pr45,Pr46,Pr47,Pr48,Pr49,Pr50,Pr51,Pr52,Pr53,Pr54,Pr55,Pr56,Pr57,Pr58,Pr59,Pr60,
				Pr61,Pr62,Pr63,Pr64,Pr65,Pr66,Pr67,Pr68,Pr69,Pr70, Total, Remarks) 
        VALUES ('".$id."',
        '".$ans[40]."','".$ans[41]."','".$ans[42]."','".$ans[43]."','".$ans[44]."','".$ans[45]."','".$ans[46]."','".$ans[47]."','".$ans[48]."','".$ans[49]."',
		'".$ans[50]."','".$ans[51]."','".$ans[52]."','".$ans[53]."','".$ans[54]."','".$ans[55]."','".$ans[56]."','".$ans[57]."','".$ans[58]."','".$ans[59]."',
		'".$ans[60]."','".$ans[61]."','".$ans[62]."','".$ans[63]."','".$ans[64]."','".$ans[65]."','".$ans[66]."','".$ans[67]."','".$ans[68]."','".$ans[69]."',
        '".$tot3."','".$remarks3."')";
  $result = mysqli_query($conn ,$sql);
  
	$type="";
	$stmt = $conn->prepare("SELECT Type FROM account WHERE Id = ?");
  	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($type);
	$stmt->fetch();
	
	if($type=="hybrid"){
		$conn = new mysqli ($servername, $username, $password, $dbName);
		$prog="game";
		$stmt = $conn->prepare("Update account Set Progress = ? WHERE Id = ?");
		$stmt->bind_param("ss",$prog,$id);
		$stmt->execute();
	}
	else{
		$conn = new mysqli ($servername, $username, $password, $dbName);
		$prog="posttest";
		$stmt = $conn->prepare("Update account Set Progress = ? WHERE Id = ?");
		$stmt->bind_param("ss",$prog,$id);
		$stmt->execute();
	}
	
	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("Update user Set PretestScore = ? WHERE Id = ?");
	$stmt->bind_param("ss",$total,$id);
	$stmt->execute();
?>
<!DOCTYPE html>
<html>
    <head>
        
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      
        <title>Healthy Foodie</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="style2.css">
	<script src="js/jquery.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<script src="js/imgzoom.min.js"></script>
	<script src="js/scrollreveal.min.js"></script>
	<script src="js/countdown.min.js"></script>
        <link rel="stylesheet" href="footer.css">
		
		<style>
		#pas{
        color: White;
        background-color:#373331;
        width: 50%;
         border-radius: 25px;
         border: 2px ;
        border-style: solid;
        border-color: #251f17;  
        }   
        table{
            background-color: #03cea4;
            border-radius: 9px;
            color: black;  
            border: 3px solid gray;
            width:45%;
        }

        td,tr,th{
            text-align: center;
            font-size: 25px;
            border:none;
        }
		</style>
    </head>
    
    
    
    <body>
        
        <div id="nav">
	  <a class="navbar-brand navbar-link" href="index.php"><img src="logo_HF.png" id="logo"></a>
        <div class="container">
            <div class="pull-left">
                <div id="logo">

                </div>
            </div>
			
			
			
			
            <div class="pull-right">
                <ul id="navigation">
                    <li><a href="home.php">HOME</a></li>
                    <li class="active"><a href="test.php">TESTS</a></li>
                    <li><a href="aboutus.php">ABOUT US</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                    </ul>
            </div>
            <div class="clear"></div>
        </div>
    </div>

    <br>
	<!--<div id="slider">
		<div class="imgheader" style="background-image: url(slidernew_HF.png);"></div>
	</div>-->
	<br></br>
    <br>
	<h1 align="center">Test Successful!</h1>
	<table align="center">
		<tr><th colspan="2"><h2>Pre Test Results</h2></th></tr>
		<tr><th>Part 1</th><td><?= $remarks1?></td></tr>
		<tr><th>Part 2</th><td><?= $remarks2?></td></tr>
		<tr><th>Part 3</th><td><?= $remarks3?></td></tr>
	</table>
	

    <br>
	<br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
	

        <footer>
                  <br>

         <p class="follow">FOLLOW US</p>
         <img class="footdog" src="food_coco.png" alt="">
         <!--<img class="footdog" src="food_apple.png" alt="">-->
         <img class="pup" src="food_orange.png" alt="" style=" width:300px;">
          <div class="container1">
		
		<ul class="social">

			<li class="facebook"><a href="#" class="entypo-facebook"></a></li>
			<li class="twitter"><a href="#" class="entypo-twitter"></a></li>
			<li class="dribbble"><a href="#" class="entypo-dribbble"></a></li>
			<li class="behance"><a href="#" class="entypo-behance"></a></li>
			<li class="linked-in"><a href="#" class="entypo-linkedin"></a></li>

		</ul>
            
	</div>  
         <div class="wrap">
       
         <div class="email"></div><br><br><br><br><br><br><br>
        
         <hr><br><br>
         <div>

             <img class="w1" src="white1.png" alt="">
             <div class="abt"><br><br>
             <p class="footerp"> The Healthy Foodie Nutrion App<br>
                 is an interactive game that teaches  <br>
				 children the Basic Food Groups, which <br>
                 is the Go, Grow, and Glow Food, The <br>
                 Filipino Food Plate, and the Traffic <br>
                 Light Food Groups. <br>
             </p>
             
             </div>
         </div>
         <div>
              <img class="w2" src="white2.png" alt="">
              <div class="inf"><br><br>
              <ul>
                  <li><a href="">About Us</a></li>
                  <li><a href="">Pre Test</a></li>
                  <li><a href="">Post Test</a></li>
              </ul>
              </div>
         </div>
         <div>
              <img class="w3" src="WHITE3.png" alt="">
              <div class="serv"><br><br>
              <ul>
                  <li><a href="">Add Suggestions</a></li>
                  <li><a href="">Ask Developers</a></li>
                  <li><a href="">Request for Citation<br> of Resources</a></li>
              </ul>
              </div>
         </div>
         <div>
              <img class="w4" src="WHITE4.png" alt="">
              <div class="cnt"><br><br>
              <p class="footerp"> Contact the Administrator <br>or contact the client<br><br>
                  <!--Phone #:<br>-->Client: 836-8955<br>Admin: 836-8955<br>
                  Email. healthyfoodie@gmail.com
             </p>
             
              </div>
         </div>
        </div> 
         <div class="foot">
             <p class="foot1"> ©2018 The Healthy Foodie Nutrition Application. All rights reserved<p>
         </div>
    </footer>
    
    </body>
</html>
