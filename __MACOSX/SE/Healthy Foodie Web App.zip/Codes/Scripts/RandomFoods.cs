﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomFoods : MonoBehaviour {
    public Transform lists;
    public GameObject food1;
    public GameObject food2;
    public GameObject food3;
    public GameObject food4;
    public GameObject food5;
    public GameObject food6;
    public GameObject food7;
    public GameObject food8;
    public GameObject food9;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void ShuffleFoods()
    {
        List<int> foods = new List<int>();
        foods.Add(0);
        foods.Add(1);
        foods.Add(2);
        foods.Add(3);
        foods.Add(4);
        foods.Add(5);
        foods.Add(6);
        foods.Add(7);
        foods.Add(8);
        int m = foods.Count;
        int n = m;
        while (n > 1)
        {
            n--;
            int k = Random.Range(0, n);
            int value = foods[k];
            foods[k] = foods[n];
            foods[n] = value;
        }

        for (int i = 0; i < m; i++)
        {
            switch (foods[i])
            {
                case 0:
                    //lists.parent = food1.transform;
                    Debug.Log(foods[i]);
                    food1.transform.SetAsFirstSibling();
                    break;
                case 1:
                    Debug.Log(foods[i]);
                    food2.transform.SetAsFirstSibling();
                    break;
                case 2:
                    Debug.Log(foods[i]);
                    food3.transform.SetAsFirstSibling();
                    break;
                case 3:
                    Debug.Log(foods[i]);
                    food4.transform.SetAsFirstSibling();
                    break;
                case 4:
                    Debug.Log(foods[i]);
                    food5.transform.SetAsFirstSibling();
                    break;
                case 5:
                    Debug.Log(foods[i]);
                    food6.transform.SetAsFirstSibling();
                    break;
                case 6:
                    Debug.Log(foods[i]);
                    food7.transform.SetAsFirstSibling();
                    break;
                case 7:
                    Debug.Log(foods[i]);
                    food8.transform.SetAsFirstSibling();
                    break;
                case 8:
                    Debug.Log(foods[i]);
                    food9.transform.SetAsFirstSibling();
                    break;
            }
        }
    }
}
