<?php 
    SESSION_START();
    require_once('compiled.php');

    if(!isset($_SESSION['usernameinput'])){
        $_SESSION['usernameinput'] = "";
        $_SESSION['firstnameinput'] = "";
        $_SESSION['lastnameinput'] = "";
        $_SESSION['middlenameinput'] = "";
        $_SESSION['emailinput'] = "";
        $_SESSION['passwordinput'] = "";
        $_SESSION['contactinput'] = "";
        $_SESSION['addressinput'] = "";
    }

    if(isset($_POST['submit'])){
        $_SESSION['usernameinput'] = $_POST['username'];
        $_SESSION['firstnameinput'] = $_POST['firstname'];
        $_SESSION['lastnameinput'] = $_POST['lastname'];
        $_SESSION['middlenameinput'] = $_POST['middlename'];
        $_SESSION['emailinput'] = $_POST['email'];
        $_SESSION['passwordinput'] = $_POST['password'];
        $_SESSION['contactinput'] = $_POST['contact'];
        $_SESSION['addressinput'] = $_POST['address'];

        if(!signup($_SESSION['usernameinput'], $_SESSION['firstnameinput'], $_SESSION['lastnameinput'], 
                   $_SESSION['middlenameinput'], $_SESSION['emailinput'], $_SESSION['passwordinput'],
                   $_SESSION['contactinput'], $_SESSION['addressinput'])){

            header('Location: index.php');
        }
        else{
            header('Location: home.php');
        }
    }
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>trial1_sneaks</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/4.1.0/cosmo/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-icons/3.0.1/iconfont/material-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aldrich">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+SC">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Anton">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arsenal">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body>
    <nav class="navbar navbar-light navbar-expand-md fixed-top" style="color:#b5c6d7;background-color:#6f7a85;">
        <div class="container-fluid"><a class="navbar-brand text-white" href="index.php" style="color:#FBFCFC;font-size:30px;font-family:sans-serif;padding:-33px;margin:0px;height:63px;"><img class="rounded-circle" src="assets/img/SHOES-logo-mono.png" width="50" height="50" style="background-size:initial;"><strong>&nbsp;SNEAKS</strong></a>
            <button
                class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navcol-1"></div>
        </div>
    </nav>
    <div class="footer-clean">
        <footer></footer>
    </div>
    <div class="register-photo">
        <div class="form-container" style="width:601px;padding:-16px;">
            <form method="post" style="background-color:#424949;width:934px;padding:50px;">
                <h2 class="text-center" style="color:#FBFCFC;font-size:39px;font-family:Allerta, sans-serif;"><strong>SIGN UP</strong></h2>
                <input class="form-control" type="text" placeholder="Username" name="username" style="margin-bottom:20px;" value="<?=$_SESSION['usernameinput'] ?>" required>
                <input class="form-control" type="text" placeholder="First Name" name="firstname" style="margin-bottom:20px;" value="<?=$_SESSION['firstnameinput'] ?>"required>
                <input class="form-control" type="text" placeholder="Middle Name" name="middlename"  style="margin-bottom:20px;" value="<?=$_SESSION['middlenameinput'] ?>">
                <input class="form-control" type="text" placeholder="Last Name" name="lastname" style="margin-bottom:20px;" value="<?=$_SESSION['lastnameinput'] ?>"required>
                <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password" value="<?=$_SESSION['passwordinput'] ?>"required></div>
                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email" style="margin-bottom:20px;" value="<?=$_SESSION['emailinput'] ?>"required>
                <input class="form-control" type="number" name="contact" placeholder="Contact" style="margin-bottom:20px;" value="<?=$_SESSION['contactinput'] ?>"required>
                <input class="form-control" type="text" name="address" placeholder="Address" value="<?=$_SESSION['addressinput'] ?>"required></div>
                <div class="form-group">
                    <div class="form-check" style="color:#FBFCFC;"><label class="form-check-label">
                        <input class="form-check-input" type="checkbox">I agree to the license terms.</label></div>
                </div>
                <div class="form-group"><button class="btn btn-primary btn-block" name="submit" type="submit" style="background-color:#FBFCFC;color:#424949;"><strong>Sign Up</strong></button></div><a href="index.html" class="already" style="color:#FBFCFC;">You already have an account? Login here.</a></form>
        </div>
    </div>
    <div class="footer-clean" style="background-color:#424949;padding:32px;">
        <footer>
            <div class="container">
                <div class="row justify-content-center" style="background-color:rgba(251,252,252,0);">
                    <div class="col-sm-4 col-md-3 item" style="padding-right:0;">
                        <h3 style="color:#FBFCFC;">ABOUT US</h3>
                        <ul>
                            <li style="color:#FBFCFC;"><a href="#">Company</a></li>
                            <li style="color:#FBFCFC;">Shipping Information</li>
                            <li style="color:#FBFCFC;">Privacy Policy</li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3 style="color:#FBFCFC;">CONTACT US</h3>
                        <ul>
                            <li><a href="#" style="color:rgb(246,249,251);">España Blvd, Sampaloc, Manila</a></li>
                            <li style="color:#FBFCFC;"><a href="#">406 1611</a></li>
                            <li></li>
                        </ul><a href="#" style="color:#FBFCFC;">sneaks.ph@gmail.com</a></div>
                    <div class="col-lg-3 item social"><a href="#" style="background-color:#424949;"><i class="icon ion-social-facebook" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-twitter" style="color:#FBFCFC;background-color:#424949;"></i></a>
                        <a
                            href="#" style="background-color:#424949;"><i class="icon ion-social-snapchat" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-instagram" style="color:#FBFCFC;"></i></a>
                            <p class="copyright"
                                style="color:#FBFCFC;font-size:21px;">Sneaks © 2018</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>