<?php 
    SESSION_START();
    require_once('compiled.php');
    
    (($_SESSION['username'] == "") ||($_SESSION['fname'] == "") ||($_SESSION['lname'] == "")) ? header("Location: index.php") : null;
    (isset($_SESSION['username'])) ? $detailsarr = json_decode(getUser($_SESSION['username']), true) : null;

    if(isset($_POST['submit'])){
        checkoutCart($_SESSION['username'], $_SESSION['totalcost'], $_POST['contact'], $_POST['email'],$_POST['paymentoption'],$_POST['address']);
            //header("Location: home.php");
    }
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>trial1_sneaks</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/4.1.0/cosmo/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-icons/3.0.1/iconfont/material-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aldrich">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+SC">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Anton">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arsenal">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body style="padding:0px;margin:-1px;">
    <nav class="navbar navbar-light navbar-expand-md" style="background-color:#6f7a85;">
        <div class="container-fluid"><a class="navbar-brand text-monospace text-white" href="home.php" style="font-size:30px;color:white;font-family:sans-serif;"><img src="assets/img/SHOES-logo-mono.png" width="50" height="50"><strong>&nbsp;SNEAKS</strong></a><button class="navbar-toggler"
            data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="#"></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link text-capitalize text-white-50 active d-table-cell float-right" href="home.php" style="font-size:20px;font-family:sans-serif;margin-top:8px;color:#FBFCFC;"><i class="fa fa-tags"></i><strong>&nbsp;Products</strong></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link text-monospace text-white-50 d-table-cell float-right" href="cart.php" style="font-size:20px;font-family:sans-serif;margin-top:8px;"><i class="fa fa-shopping-cart"></i><strong>&nbsp;Cart</strong></a></li>
                    <li class="dropdown"><a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" style="margin:0px;font-size:25px;color:rgba(255,255,255,0.5);"><i class="icon ion-android-person" style="font-size:30px;color:rgba(255,255,255,0.5);"></i>&nbsp;<?php echo $_SESSION['fname'] . " " . $_SESSION['lname']?></a>
                        <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="account.php"><strong>Profile</strong></a><a class="dropdown-item" role="presentation" href="index.html"><strong>Log Out</strong></a></div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <h1 style="font-size:41px;font-family:Anton, sans-serif;padding:10px;color:#424949;"><i class="fa fa-pencil-square-o"></i>&nbsp;CHECK OUT FORM</h1>
    </div>
    <hr>
    <div class="container" style="padding-left:90px;background-color:#424949;padding-top:15px;padding-bottom:15px;width:800px;">
        <form METHOD="POST">
            <h1 style="font-size:20px;color:#FBFCFC;"><strong>NAME</strong></h1><input type="text" name="name" required disabled placeholder="ex. Dela Cruz, Juan" style="width:600px;margin:5px;" value="<?=$detailsarr['U_LastName'] . ", " . $detailsarr['U_FirstName'] ?>">
            <h1 style="font-size:20px;color:#FBFCFC;"><strong>BILLING ADDRESS</strong></h1><input type="text" required name="address" placeholder="ex. Unit 7J Avida Tower 2 San Lazaro Felix Huertas St. Sta. Cruz, Manila" style="width:600px;margin:5px;" value="<?=$detailsarr['U_Address']?>">
            <h1 style="font-size:20px;color:#FBFCFC;"><strong>CONTACT NUMBER</strong></h1><input type="text" required name="contact" placeholder="ex. 09163265678" style="width:600px;margin:5px;" value="<?=$detailsarr['U_Contact']?>">
            <h1 style="font-size:20px;color:#FBFCFC;"><strong>EMAIL ADDRESS</strong></h1><input type="text" required name="email" placeholder="ex. delacruz.juan@gmail.com" style="width:600px;margin:5px;" value="<?=$detailsarr['U_Email']?>">
            <h1 style="font-size:20px;color:#FBFCFC;"><strong>METHOD OF PAYMENT</strong></h1>
            <div class="form-check" style="padding-bottom:0px;margin:5px;"><input class="form-check-input" required name="paymentoption" value="COD" checked type="radio" id="formCheck-1"><label class="form-check-label" for="formCheck-1" style="color:#FBFCFC;">Cash on Delivery</label></div>
            <h1 style="font-size:20px;padding-left:190px;"><button class="btn btn-primary" type="submit" name="submit" style="background-color:#FBFCFC;width:128px;margin:5px;padding-left:50px;padding-right:170px;color:#424949;font-size:25px;"><strong>CHECK OUT</strong></button></h1>
        </form>
    </div>
    <hr>
    <div></div>
    <div class="footer-clean" style="background-color:#424949;padding:32px;">
        <footer>
            <div class="container">
                <div class="row justify-content-center" style="background-color:rgba(251,252,252,0);">
                    <div class="col-sm-4 col-md-3 item" style="padding-right:0;">
                        <h3 style="color:#FBFCFC;">ABOUT US</h3>
                        <ul>
                            <li style="color:#FBFCFC;"><a href="#">Company</a></li>
                            <li style="color:#FBFCFC;">Shipping Information</li>
                            <li style="color:#FBFCFC;">Privacy Policy</li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3 style="color:#FBFCFC;">CONTACT US</h3>
                        <ul>
                            <li><a href="#" style="color:rgb(246,249,251);">España Blvd, Sampaloc, Manila</a></li>
                            <li style="color:#FBFCFC;"><a href="#">406 1611</a></li>
                            <li></li>
                        </ul><a href="#" style="color:#FBFCFC;">sneaks.ph@gmail.com</a></div>
                    <div class="col-lg-3 item social"><a href="#" style="background-color:#424949;"><i class="icon ion-social-facebook" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-twitter" style="color:#FBFCFC;background-color:#424949;"></i></a>
                        <a
                            href="#" style="background-color:#424949;"><i class="icon ion-social-snapchat" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-instagram" style="color:#FBFCFC;"></i></a>
                            <p class="copyright"
                                style="color:#FBFCFC;font-size:21px;">Sneaks © 2018</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>