<?php
	if(isset($_POST['game']))
	{
		if($_POST['game']=="done"){

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		


		  $conn = new mysqli ($servername, $username, $password, $dbName);
		  if(!$conn){
			  die("Connection Failed. ".mysqli_connect_error);
		  }
			session_start();
		  $id=$_SESSION['id'];
		  
		  
		  $prog="posttest";
			$stmt = $conn->prepare("Update account Set Progress = ? WHERE Id = ?");
			$stmt->bind_param("ss",$prog,$id);
			$stmt->execute();
		}
		header('Location:posttest.php');
	}
	else{
		header('Location:test.php');
	}

?>