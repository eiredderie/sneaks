
<!DOCTYPE html>
<html>
    <head>
        
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      
        <title>Healthy Foodie</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="style2.css">
	<script src="js/jquery.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="js/imgzoom.min.js"></script>
	<script src="js/scrollreveal.min.js"></script>
	<script src="js/countdown.min.js"></script>
        <link rel="stylesheet" href="footer.css">
        <style>
            h1{
                font-family: montserrat;
                color: #080808;
                text-shadow: 0 0 3px #FF0000, 0 0 5px #0000FF;
            }
            #wrapper{
                background-color: #D23641;
            }
            h4{
                font-family: montserrat;
                color: #FFFFFF;
            }
            #wrapper1{
                background-color: #6E6568;
            }
            .title {
                float:left;
                width:100%;
                height:142px;
            }
            .menu {
                float:left;
                width:100%;
                height:400px;
            }
            #wrapper{
                background-color: #D23641;
            }
            .main {
                float:right;
                width:100%;
                height:400px;
            }
            .foot {
                float:left;
                width:100%;
                height:50px;
            }
        </style>
    </head>
    
    
    
    <body>
        
        <div id="nav">
	  <a class="navbar-brand navbar-link" href="index.php"><img src="logo_HF.png" id="logo"></a>
        <div class="container">
            <div class="pull-left">
                <div id="logo">

                </div>
            </div>
            <div class="pull-right">
                <ul id="navigation">
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="test.php">TESTS</a></li>
                    <li class="active"><a href="aboutus.php">ABOUT US</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                    <li><a href="logout.php">LOGOUT</a></li>
                    </ul>
            </div>
            <div class="clear"></div>
        </div>
    </div>

    <br>
	<br>
	<div class="container-fluid">
            <br>
            <div class="row" align="center">
                <div class="col-md-12">
                    <h1 class="text-center">HEALTHY FOODIE <br>NUTRITION APPLICATION</h1>
                </div>
            </div>
        </div>
        <br>
        <div class="container-fluid">
            <div class="row" align="center">
				<div class="col-md-1">
                </div>
                <div class="col-md-3">
                    <iframe class="menu" src="menu.html"></iframe>
                </div>
				<div class="col-md-1">
                </div>
                <div class="col-md-6">
                    <iframe class="main" style="background-image:url(bb.jpg); background-size:cover;" name="main" src="obj.html"></iframe>
                </div>
            </div>
        </div>
        <br>
        <div class="container-fluid">
            <div class="row" align="center">
                
            </div>
        </div>
	

    
    </body>
</html>
