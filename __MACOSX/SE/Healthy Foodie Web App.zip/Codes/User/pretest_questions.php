<?php
session_start();
if(isset($_POST['pretest'])){
	$i=$_SESSION['q_no']+1;
	if (isset($_POST['q'.$i])) {
      $_SESSION['pr'.$_POST['num']]=$_POST['q'.$i];
    }
    else{
      $_SESSION['prq'.$i]="X";
    }
	$_SESSION['q_no']+=1;
	header("Location:pretest.php");
}
else{
	if(isset($_SESSION['q_no']))
		$_SESSION['q_no']=$_SESSION['q_no'];
	else
		$_SESSION['q_no']=0;
}



?>