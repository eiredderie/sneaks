<?php
session_start();

if(isset($_POST['pretest'])){
		$_SESSION['pretest']=$_POST['pretest'];
		header('Location:pretestscore.php');
		
}
else if(isset($_POST['posttest'])){
	$_SESSION['posttest']=$_POST['posttest'];
		header('Location:posttestscore.php');
		
}
if(isset($_POST['buttons'])){
	if($_POST['buttons']=="Go Back"){
		header('Location:dbpage.php');
	}
	else if($_POST['buttons']=="Students"){
		header('Location:viewstudents.php');
	}
	else{
		header('Location:logout.php');
	}
}

if(isset($_SESSION['access'])){
	

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		
	
	$conn = new mysqli ($servername, $username, $password, $dbName);

	$sql = "SELECT * FROM user"; //You don't need a ; like you do in SQL
	$result = mysqli_query($conn ,$sql);	
	
	echo "
		<!DOCTYPE html>
		<html>
		<head>
		<meta charset='ISO-8859-1'>
		<title>HEALTHY FOODIE</title>
		</head>
		<style>

		body {
			background-image:url('background2.jpg');
		    background-size: 100%;
		    background-repeat: repeat;
		    font-family: Arial Narrow;
		    background-color: brown;
		    font-size: 20px;
		 	
		}
		fieldset, h1 {
			background-color: white;
			border: 1px solid black;
			border-radius: 25px;
			color: #f2da94;
		}
		button{
			padding: 15px 30px;
			font-size: 20px;
			background-color: brown;
			background-color: #eeb063;
		}
		fieldset{
			background-color : #8c2a27;
		}
		#pas {
			color: #c74535;
			background-color: #eeb063;
		}
		#out{
			font-size: 15px;
			padding: 10px 20px;
		}
		#stud{
			font-size: 15px;
			padding: 5px 10px;
		}
		table{
            background-color: #03cea4;
            border-radius: 9px;
            color: black;  
            border: 3px solid gray;
            width:45%;
        }

        td,tr,th{
            text-align: center;
            font-size: 20px;
            border:none;
        }
		</style>
		<body>
			<center><img src='header.png' class='img-responsive' height='300' width='600' >

			<br><br>
			
			<form action='' method='POST'>
			
			
			
			<center><fieldset> 
			
				<table>
					<center><legend><h1 id = 'pas'><b>&nbsp DATABASE &nbsp <b/></h1></legend></center>";
					$names=mysqli_fetch_assoc($result);
					if($names!=NULL){
						$columns=array_keys($names);
						echo "<tr>";
						$result = mysqli_query($conn ,$sql);
						for ($i = 0; $i < mysqli_num_fields($result); $i++) {
						echo  "<th>".$columns[$i] . "</th>";
						}
						echo "</tr>";
							while($row= mysqli_fetch_row($result))
							{
								echo "<tr>";
								for($j=0; $j<mysqli_num_fields($result);$j++)
								{
									if(!isset($row[$j]))
										echo "<td>Null</td>";
									else if($j==5)
										if(!is_numeric($row[$j]))
											echo "<td><center>To be taken</center></td>";
										else
											echo "<td><center><button id='stud' type=submit name=pretest value='".$row[0]."'>".$row[$j]."</center></button></td>";
									else if($j==6)
										if(!is_numeric($row[$j]))
											echo "<td><center>To be taken</center></td>";
										else
											echo "<td><center><button id='stud' type=submit name=posttest value='".$row[0]."'>".$row[$j]."</center></button></td>";
									else
										echo "<td>".$row[$j]."</td>";
								}
								echo "</tr>";
								$row--;
							}   
					}
					else{
						echo "NO DATA";
					}
					echo "
				</table>	
				<br><br>
				<p> <button id='out' type=submit name=buttons value='Go Back'><b>Go Back</b></button>

			</fieldset></center>
			</form>
		</body>
		</html>

		</form>
		</body>
	";
}
else{
	header('Location:login.php');
}
?>

