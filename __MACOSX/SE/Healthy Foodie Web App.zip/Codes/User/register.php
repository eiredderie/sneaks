<?php
 session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>HEALTHY FOODIE</title>
</head>
<style>

body {
	background-image:url("background2.jpg");
    background-size: 100%;
    background-repeat: repeat;
    font-family: Arial Narrow;
    background-color: brown;
    font-size: 20px;
 	
}
fieldset, h1 {
	background-color: white;
	border: 1px solid black;
	border-radius: 25px;
	color: #f2da94;
}
button{
	padding: 15px 30px;
	font-size: 20px;
	background-color: brown;
	background-color: #eeb063;
}
fieldset{
	background-color : #8c2a27;
}
#pas {
	color: #c74535;
	background-color: #eeb063;
}

</style>
	<center><img src="header.png" class="img-responsive" height="300" width="600" ></center>
<body>

	<br><br>
	
	<form action="registerdb.php" method="post">
	
	
	<center><fieldset> 
	
		<table>
			<center><legend><h1 id = "pas"><b>&nbsp REGISTER &nbsp <b/></h1></legend></center>
			<tr> <td colspan="2"><b><?php if(isset($_SESSION['rmsg'])) echo $_SESSION['rmsg'];?></b></td> </tr>
			<tr> <td><b><h2>Name:</h2></b></td>	<td><input type="text" name="name" style="font-size:20pt;" required autofocus/></td> </tr>
			<tr> <td><b><h2>Age:</h2></b></td>	<td><input type="number" name="age" min="5" max="12" style="font-size:20pt;" required autofocus/></td> </tr>
			<tr> <td><b><h2>Gender:</h2></b></td>	<td>
				<input type="radio" name="gender" value="male" style="font-size:20pt;" required autofocus/> <b style="font-size:20pt;">Male</b>
				<input type="radio" name="gender" value="female" style="font-size:20pt;" required autofocus/> <b style="font-size:20pt;">Female</b>
			</td> </tr>
			<tr> <td><b><h2>Grade:</h2></b></td>	<td>
				<select name="grade" style="font-size:20pt;" required autofocus/>
				<option value="Grade 1">Grade 1</option>
				<option value="Grade 2">Grade 2</option>
				<option value="Grade 3">Grade 3</option>
				<option value="Grade 4">Grade 4</option>
				<option value="Grade 5">Grade 5</option>
				<option value="Grade 6">Grade 6</option>
				<!--<option value="N/A">None of the above</option>-->
				<select>
			</td> </tr>
			<tr> <td><b><h2>Username:</h2></b></td>	<td><input type="text" name="uname" style="font-size:20pt;" required autofocus/></td> </tr>
			<tr> <td><b><h2>Password:</h2></b></td> 	<td><input type="password" name="upass" style="font-size:20pt;" required /></td> </tr>
			<tr> <td><b><h2>Account Type:</h2></b></td>	<td>
				<input type="radio" name="type" value="hybrid" style="font-size:20pt;" required autofocus/> <b style="font-size:20pt;">Hybrid</b>
				<input type="radio" name="type" value="testonly" style="font-size:20pt;" required autofocus/> <b style="font-size:20pt;">Tests Only</b>
			</td> </tr>
		</table>	
		<p> <button type="submit" name="login" value="Submit"><b>Submit</b></button> 
		
		
		<p> Already have an account? <a href="index.php">Log in</a>
	</fieldset></center>
	</form>

	
</body>
</html>
