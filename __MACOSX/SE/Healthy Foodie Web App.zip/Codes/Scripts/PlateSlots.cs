﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class PlateSlots : MonoBehaviour, PlateChanged
{
    [SerializeField] Transform go;
    [SerializeField] Transform grow;
    [SerializeField] Transform glow;
    public TextMeshProUGUI plateError;

    int gos = 0;
    int grows = 0;
    int glows = 0;
    int items = 0;
    // Use this for initialization
    void Start()
    {
        HasChanged();
    }

    // Update is called once per frame
    public void HasChanged()
    {
        gos = 0;
        grows = 0;
        glows = 0;
        items = 0; 
        foreach (Transform slotTransform1 in go)
        {
            GameObject item = slotTransform1.GetComponent<Item>().item;
            if (item)
            {
                switch (item.name)
                {
                    case "Rice":
                        gos += 1;
                        break;
                    case "Spag":
                        gos += 1;
                        break;
                    case "Bread":
                        gos += 1;
                        break;
                }
                items += 1;
            }
        }

        foreach (Transform slotTransform2 in grow)
        {
            GameObject item = slotTransform2.GetComponent<Item>().item;
            if (item)
            {
                switch (item.name)
                {
                    case "Fish":
                        grows += 1;
                        break;
                    case "Chicken":
                        grows += 1;
                        break;
                    case "Egg":
                        grows += 1;
                        break;
                }
                items += 1;
            }
        }

        foreach (Transform slotTransform3 in glow)
        {
            GameObject item = slotTransform3.GetComponent<Item>().item;
            if (item)
            {
                switch (item.name)
                {
                    case "Apple":
                        glows += 1;
                        break;
                    case "Banana":
                        glows += 1;
                        break;
                    case "Mango":
                        glows += 1;
                        break;
                    case "Tomato":
                        glows += 1;
                        break;
                }
                items += 1;
            }
        }
    }

    public void onClick()
    {
        if (gos == 1 && grows == 1 && glows == 2)
        {
            plateError.text = "";
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
        else
        {
            if (items != 4) { 
                Debug.Log(items);
                plateError.text = "Please fill the plate with 4 foods.";
            }
            else
                plateError.text = "The food(s) does not match the correct food group.";
        }


    }
}

namespace UnityEngine.EventSystems
{
    public interface PlateChanged : IEventSystemHandler
    {
        void HasChanged();
    }
}
