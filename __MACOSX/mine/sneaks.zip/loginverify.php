<?php
require_once dirname(__FILE__).'/methods.php';

login($_POST['email'],$_POST['password']);



?>