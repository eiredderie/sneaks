<?php
	session_start();
	if(isset($_POST['login'])){

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		
		
		$conn = new mysqli ($servername, $username, $password, $dbName);
		
		$uname = $_POST["uname"];
		$pass = $_POST["upass"];
		$encryptpass=md5($pass);
		$stmt = $conn->prepare("SELECT Id FROM account WHERE Username = ? AND Password = ?");
		echo $conn->error;
		$stmt->bind_param("ss",$uname,$encryptpass);
		$stmt->execute();
		$stmt->bind_result($results);
		$stmt->fetch();


		if(!$conn){
			$_SESSION['msg']="Website is down";
			header('Location:index.php');
		}
		if($results>=1){
			$_SESSION['access']="true";
			$_SESSION['q_no']=0;
			$_SESSION['id']=$results;
			header('Location:home.php');
		}
		else{
			$_SESSION['msg']="Incorrect Username and Password";
			header('Location:index.php');
		}
		$stmt->close();
		$conn->close();
	}
	else{
		header('Location:index.php');
	}

?>