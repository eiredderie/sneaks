<?php
	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		
	

$conn = new mysqli ($servername, $username, $password, $dbName);
if(!$conn){
		die("Connection Failed. ".mysqli_connect_error);
}


$id=$_GET["id"];
$name = $_GET["name"];
$age = $_GET["age"];
$gender = $_GET["gender"];
$grade = $_GET["grade"];

$sql = "INSERT INTO user (Id, Name, Age, Gender, Grade) 
				VALUES ('".$id."','".$name."','".$age."','".$gender."','".$grade."')";
		$result2 = mysqli_query($conn ,$sql);


header('Location:registered.php');

?>