﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class PyramidSlots : MonoBehaviour, PyramidChanged
{
    [SerializeField] Transform green;
    [SerializeField] Transform yellow;
    [SerializeField] Transform red;
    public TextMeshProUGUI pyramidError;

    int greens = 0;
    int yellows = 0;
    int reds = 0;
    int total = 0;

    // Use this for initialization
    void Start()
    {
        HasChanged();
    }

    // Update is called once per frame
    public void HasChanged()
    {
        greens = 0;
        yellows = 0;
        reds = 0;
        total = 0;
        foreach (Transform slotTransform1 in green)
        {
            GameObject item = slotTransform1.GetComponent<Slot>().item;
            if (item)
            {
                switch (item.name)
                {
                    case "Rice":
                        greens += 1;
                        break;
                    case "Shrimp":
                        greens += 1;
                        break;
                    case "Tomato":
                        greens += 1;
                        break;
                }
                total += 1;
            }
        }

        foreach (Transform slotTransform2 in yellow)
        {
            GameObject item = slotTransform2.GetComponent<Slot>().item;
            if (item)
            {
                switch (item.name)
                {
                    case "Pizza":
                        yellows += 1;
                        break;
                    case "Hotdog":
                        yellows += 1;
                        break;
                    case "Pancake":
                        yellows += 1;
                        break;
                }
                total += 1;
            }
        }
        foreach (Transform slotTransform3 in red)
        {
            GameObject item = slotTransform3.GetComponent<Slot>().item;
            if (item)
            {

                switch (item.name)
                {
                    case "IceCream":
                        reds += 1;
                        break;
                    case "Donut":
                        reds += 1;
                        break;
                    case "Fries":
                        reds += 1;
                        break;
                    case "Cake":
                        reds += 1;
                        break;
                }
                total += 1;
            }
        }
    }

    public void onClick()
    {
        if (greens == 3 && yellows == 2 && reds == 1)
        {
            pyramidError.text = "";
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
        else
        {
            if (total != 6)
            {

                Debug.Log(total);
                pyramidError.text = "Please fill all the slots in the food pyramid.";
            }
            else
                pyramidError.text = "The food(s) does not match the correct food group.";
        }


    }
}

namespace UnityEngine.EventSystems
{
    public interface PyramidChanged : IEventSystemHandler
    {
        void HasChanged();
    }
}
