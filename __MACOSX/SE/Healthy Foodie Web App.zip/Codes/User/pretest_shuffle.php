<?php
//PRETEST SHUFFLE
session_start();

$_SESSION['q1']=array("Carbohydrates Belong to which food group?","Which food groups provides proteins?",
					"Vitamins are part of which food group?","Which food group provides energy for you to play?",
					"Which Food Group keeps your muscles strong?","Which Food Group gives many Minerals?",
					"Fruits and vegetables belong to which food group?","Which food provides energy for you to study?",
					"Which food group helps keep your bones healthy?","Which food group will help make your hair shiny?"
					);
$_SESSION['q2']="Identify the Food Group where this food belongs.";
$_SESSION['q3']="How often should you eat these foods?";	
$_SESSION['question01']=array(
					//IMAGES FOR #1-10 ako na bahala dito
					array("foods/spaghetti.png","foods/pork.png","foods/watermelon.png",
					"foods/cereal.png","foods/egg.png","foods/apple.png",
					"foods/coconut.png","foods/pandesal.png","foods/fish.png",
					"foods/eggplant.png"),
					array(1,2,3,1,2, 3,3,1,2,3), //1 = GO FOOD, 2= GROW FOOD, 3= GLOW FOOD //correct answer
					array("Spaghetti","Pork (Baboy)","Watermelon (Pakwan)","Cereal","Egg (Itlog)", 
					"Apple (Mansanas)","Coconut (Buko)","Pandesal","Fish (Isda)","Eggplant (Talong)"),
					array("q1","q2","q3","q4","q5","q6","q7","q8","q9","q10")
					);
$_SESSION['question02']=array(
					//IMAGES FOR #11-40;
					array("foods/banana.png","foods/rice.png","foods/carrots.png","foods/Milk.png","foods/pork.png",
					"foods/cereal.png","foods/bread.png","foods/cabbage.png","foods/chicken.png","foods/apple.png",
					"foods/watermelon.png","foods/noodles.png","foods/beef.png","foods/egg.png","foods/eggplant.png",
					"foods/fish.png","foods/mango.png","foods/puto.png","foods/shrimp.png","foods/ampalaya.png",
					"foods/malungay.png","foods/coconut.png","foods/corn.png","foods/pineapple.png","foods/spaghetti.png",
					"foods/pandesal.png","foods/cheese.png","foods/monggo.png","foods/sweet potato.png","foods/tomato.png"),
					//CORRECT ANSWER FOR #11-40
					array(3,1,3,2,2,1,1,3,2,3,
					      3,1,2,2,3,2,3,1,2,3,
					      3,3,1,3,1,1,2,2,1,2),
					array("Banana (Saging)","Rice (Kanin)","Carrots","Milk (Gatas)","Pork (Baboy)",
					"Cereal","Bread (Tinapay)","Cabbage (Repolyo)","Chicken (Manok)","Apple (Mansanas)",
					"Watermelon (Pakwan)","Noodles","Beef (Baka)","Egg (Itlog)","Eggplant (Talong",
					"Fish (Isda)", "Mango (Manga)","Rice Cake (Puto)","Shrimp (Hipon)","Bittergourd (Ampalaya)",
					"Malunggay", "Coconut (Buko)","Corn (Mais)","Pineapple (Pinya)", 
					"Spaghetti","Pandesal","Cheese (Keso)","Monggo Beans","Sweet Potato (Kamote)","Tomato (Kamatis)"),
					array("q11","q12","q13","q14","q15","q16","q17","q18","q19","q20",
							"q21","q22","q23","q24","q25","q26","q27","q28","q29","q30",
							"q31","q32","q33","q34","q35","q36","q37","q38","q39","q40")
					);
					
$_SESSION['question03']=array(
					//IMAGES FOR #41-70;
					array("foods/icecream.png","foods/mango.png","foods/chips.png","foods/rice.png","foods/pancake.png","foods/donut.png","foods/coke.png","foods/cabbage.png","foods/burger.png","foods/hotdog.png",
					"foods/watermelon.png","foods/food_water.png","foods/bananaque.png","foods/pizza.png","foods/lolipop.png","foods/mashmallow.png","foods/tocino.png","foods/chicken nugget.png","foods/shrimp.png","foods/fishball.png",
					"foods/boiled banana.png","foods/coconut.png","foods/fried rice.png","foods/mayonnaise.png","foods/chicken breast.png","foods/cake.png","foods/lolipop.png","foods/fries.png","foods/kamoteque.png","foods/tomato.png"),
					//CORRECT ANSWER FOR #41-70
					array(3,1,3,1,2,3,3,1,2,2,
						  1,1,2,2,3,3,2,2,1,3,
					      1,1,2,2,1,3,3,1,2,1),
					array("Ice Cream","Mango (Manga)","Chips","Rice (Kanin)","Pancake", "Donut","Coke","Cabbage (Repolyo)","Burger","Hotdog",
					"Watermelon (Pakwan)","Water (Tubig)","Bananaque","Pizza","Candy", "Marshmallow","Tocino","Chicken Nugget","Shrimp (Hipon)","Fishball",
					"Boiled Banana","Coconut (Buko)","Fried Rice (Sinangag)","Mayonnaise","Chicken Breast", "Cake","Lollipop","Fries","Kamoteque", "Tomato (Kamatis)"),
					array("q41","q42","q43","q44","q45","q46","q47","q48","q49","q50",
							"q51","q52","q53","q54","q55","q56","q57","q58","q59","q60",
							"q61","q62","q63","q64","q65","q66","q67","q68","q69","q70")
					);

					
function shuffle_keys( $array, $answer, $name, $no ) {
    $keys = array_keys($array);

    shuffle($keys);
	$i=0;
    foreach($keys as $key) {
        $new[$i] = $array[$key];
		$temp[$i]= $answer[$key];
		$label[$i]= $name[$key];
		$num[$i]= $no[$key];
		$i++;
    }
	$array=array($new, $temp, $label, $num);
    return $array;
}

function shuffles( $array, $answer, $name , $no, $ques) {
    $keys = array_keys($array);

    shuffle($keys);
	$i=0;
    foreach($keys as $key) {
        $new[$i] = $array[$key];
		$temp[$i]= $answer[$key];
		$label[$i]= $name[$key];
		$q[$i]= $ques[$key];
		$num[$i]= $no[$key];
		$i++;
    }
    $_SESSION['q1']=$q;
	$array=array($new, $temp, $label, $num);
    return $array;
} 

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		
$id=1;
$conn = new mysqli ($servername, $username, $password, $dbName);
$stmt = $conn->prepare("SELECT PretestStat FROM settings WHERE Id = ?");
$stmt->bind_param("s",$id);
$stmt->execute();
$stmt->bind_result($stat);
$stmt->fetch();

	$_SESSION['q_no']=0;
if($stat=="YES"){
	$_SESSION['question1']=shuffles($_SESSION['question01'][0],$_SESSION['question01'][1],$_SESSION['question01'][2],$_SESSION['question01'][3],$_SESSION['q1']);
	$_SESSION['question2']=shuffle_keys($_SESSION['question02'][0],$_SESSION['question02'][1],$_SESSION['question02'][2],$_SESSION['question02'][3]);
	$_SESSION['question3']=shuffle_keys($_SESSION['question03'][0],$_SESSION['question03'][1],$_SESSION['question03'][2],$_SESSION['question03'][3]);
	
}
else{
	$_SESSION['question1']=$_SESSION['question01'];
	$_SESSION['question2']=$_SESSION['question02'];
	$_SESSION['question3']=$_SESSION['question03'];
}
header("Location:pretest.php");
?>