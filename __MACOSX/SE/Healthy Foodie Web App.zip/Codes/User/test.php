<?php
	session_start();

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		


	$conn = new mysqli ($servername, $username, $password, $dbName);
	if(!$conn){
	  die("Connection Failed. ".mysqli_connect_error);
	}

	$id=$_SESSION['id'];

  	$stmt = $conn->prepare("SELECT Progress FROM account WHERE Id = ?");
  	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($results);
	$stmt->fetch();

  $conn = new mysqli ($servername, $username, $password, $dbName);
  $stmt = $conn->prepare("SELECT Type FROM account WHERE Id = ?");
  $stmt->bind_param("s",$id);
  $stmt->execute();
  $stmt->bind_result($type);
  $stmt->fetch();

?>

<!DOCTYPE html>
<html>
    <head>
        
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      
        <title>Healthy Foodie</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="style2.css">
	<script src="js/jquery.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<script src="js/imgzoom.min.js"></script>
	<script src="js/scrollreveal.min.js"></script>
	<script src="js/countdown.min.js"></script>
        <link rel="stylesheet" href="footer.css">

        <style>
        button:disabled {
            background: #dddddd;
            color: black;
        }
        .btn {
            font-size: 30px; 
            color: black;
        }
      </style>
    </head>
    
    
    
    <body>
        
        <div id="nav">
	  <a class="navbar-brand navbar-link" href="index.php"><img src="logo_HF.png" id="logo"></a>
        <div class="container">
            <div class="pull-left">
                <div id="logo">

                </div>
            </div>
            <div class="pull-right">
                <ul id="navigation">
                    <li><a href="home.php">HOME</a></li>
                    <li class="active"><a href="test.php">TESTS</a></li>
                    <li><a href="aboutus.php">ABOUT US</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                    <li><a href="logout.php">LOGOUT</a></li>
                    </ul>
            </div>
            <div class="clear"></div>
        </div>
    </div>

    <br>
	<!--<div id="slider">
		<div class="imgheader" style="background-image: url(slidernew_HF.png);"></div>
	</div>-->
	<br></br>
    
    <br>
	<form method="POST" action="">
	    <div <?php if($type=="hybrid") echo 'class="col-lg-4"';  else echo 'class="col-lg-6"'; ?> >
				<div class="well well-lg">
					<center><h1><b>PRE TEST</b></h1></center>
					<center><image src="pretest.PNG" class="img-responsive" height="200" width="200" alt="pretest"></center><br>
					<center><button type="submit" value="true" name="pre" formaction="pretest_shuffle.php" class="btn btn-primary" <?php if($results!="pretest") echo "disabled"; ?>>Take Pretest</button></a></center>
				</div>
			</div>
			<?php
      if ($type=="hybrid"){
        echo '
        <div class="col-lg-4">
  				<div class="well well-lg">
  					<center><h1><b>GAME</b></h1></center>
  					<center><image src="hf.PNG" class="img-responsive" height="200" width="200" alt="game"></center><br>
  					<center><br><br><br><br><br><button type="submit" value="true" name="game" formaction="game.php" class="btn btn-primary"'; 
              if($results!="game") echo "disabled"; 
            echo '>Play the <b>Game</b></button></center>
  				</div>
  			</div>';
      }
      ?>
			<div <?php if($type=="hybrid") echo 'class="col-lg-4"';  else echo 'class="col-lg-6"'; ?> >
				<div class="well well-lg">
					<center><h1><b>POST TEST</b></h1></center>
					<center><image src="posttest.jpg" class="img-responsive" height="200" width="200" alt="posttest"></center><br>
					<center><br><button type="submit" value="true" name="post" formaction="posttest_shuffle.php" class="btn btn-primary" <?php if($results!="posttest") echo "disabled"; ?>>Take Posttest</button></center>
				</div>
			</div>
	</form>
	
<script src="quiz.js"></script>
<script src="question.js"></script>
<script src="app.js"></script>



    
    </body>
</html>
