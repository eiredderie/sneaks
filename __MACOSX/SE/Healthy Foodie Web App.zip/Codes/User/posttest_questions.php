<?php
session_start();
if(isset($_POST['posttest'])){
	$i=$_SESSION['q_no']+1;
	if (isset($_POST['q'.$i])) {
      $_SESSION['pt'.$_POST['num']]=$_POST['q'.$i];
      
    }else{
        $_SESSION['ptq'.$i]="X";
    }
	$_SESSION['q_no']+=1;
	header("Location:posttest.php");
}
else{
	if(isset($_SESSION['q_no']))
		$_SESSION['q_no']=$_SESSION['q_no'];
	else
		$_SESSION['q_no']=0;
}

?>