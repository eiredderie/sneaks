<?php
session_start();
if(isset($_POST['buttons'])){
	if($_POST['buttons']=="Go Back"){
		header('Location:viewstudents.php');
	}
	else{
		header('Location:logout.php');
	}
}
if(isset($_SESSION['access'])){
	

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		

	$id=$_SESSION['posttest'];

	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("SELECT name FROM user WHERE id = ?");
	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($result);
	$stmt->fetch();

	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("SELECT * FROM posttestq1 WHERE posttestq1id = ?");
	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($id1,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,$tot1,$r1);
	$stmt->fetch();
	$pr1=array($p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10);

	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("SELECT * FROM posttestq2 WHERE posttestq2id = ?");
	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($id1,
		$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,
		$p11,$p12,$p13,$p14,$p15,$p16,$p17,$p18,$p19,$p20,
		$p21,$p22,$p23,$p24,$p25,$p26,$p27,$p28,$p29,$p30,
		$tot2,$r2);
	$stmt->fetch();
	$pr2=array(
		$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,
		$p11,$p12,$p13,$p14,$p15,$p16,$p17,$p18,$p19,$p20,
		$p21,$p22,$p23,$p24,$p25,$p26,$p27,$p28,$p29,$p30,);

	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("SELECT * FROM posttestq3 WHERE posttestq3id = ?");
	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($id1,
		$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,
		$p11,$p12,$p13,$p14,$p15,$p16,$p17,$p18,$p19,$p20,
		$p21,$p22,$p23,$p24,$p25,$p26,$p27,$p28,$p29,$p30,
		$tot3,$r3);
	$stmt->fetch();
	$pr3=array(
		$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,
		$p11,$p12,$p13,$p14,$p15,$p16,$p17,$p18,$p19,$p20,
		$p21,$p22,$p23,$p24,$p25,$p26,$p27,$p28,$p29,$p30,);

	echo "
		<!DOCTYPE html>
		<html>
		<head>
		<meta charset='ISO-8859-1'>
		<title>HEALTHY FOODIE</title>
		</head>
		<style>

		body {
			background-image:url('background2.jpg');
		    background-size: 100%;
		    background-repeat: repeat;
		    font-family: Arial Narrow;
		    background-color: brown;
		    font-size: 20px;
		 	
		}
		fieldset, h1 {
			background-color: white;
			border: 1px solid black;
			border-radius: 25px;
			color: #f2da94;
		}
		button{
			padding: 15px 30px;
			font-size: 20px;
			background-color: brown;
			background-color: #eeb063;
		}
		fieldset{
			background-color : #8c2a27;
		}
		#pas {
			color: #c74535;
			background-color: #eeb063;
		}
		#out{
			font-size: 15px;
			padding: 10px 20px;
		}
		#stud{
			font-size: 15px;
			padding: 10px 10px;
		}
		table{
            background-color: #03cea4;
            border-radius: 9px;
            color: black;  
            border: 3px solid gray;
            width:45%;
        }

        td,tr,th{
            text-align: center;
            font-size: 20px;
            border:none;
        }
		</style>
		<body>
			<center><img src='header.png' class='img-responsive' height='300' width='600' >

			<br><br>
			
			<form action='' method='POST'>
			
			
			
			<center><fieldset> 
				<center><legend><h1 id = 'pas'><b>&nbsp Score of";
				echo " ".$result;
				echo " 
				 &nbsp <b/></h1></legend></center>
				<table>
					<center><legend><h1 id = 'pas'><b>&nbsp POSTTEST PART 1 SCORES &nbsp <b/></h1></legend></center>";
						echo  "<tr>";
						for($i=1;$i<=10;$i++)
						echo "<th> Q$i </th>";
						echo "<th> Total </th>";
						echo "<th> Remarks </th>";
						echo "</tr>";

						echo  "<tr>";
						foreach($pr1 as $v){
							echo "<th> $v </th>";
						}
						echo "<th> $tot1 </th>";
						echo "<th> $r1 </th>";
						echo "</tr>";
					
					echo "
				</table>	

				<br><br>

				<table>
					<center><legend><h1 id = 'pas'><b>&nbsp POSTTEST PART 2 SCORES &nbsp <b/></h1></legend></center>";
						echo  "<tr>";
						for($i=11;$i<=40;$i++)
						echo "<th> Q$i </th>";
						echo "<th> Total </th>";
						echo "<th> Remarks </th>";
						echo "</tr>";

						echo  "<tr>";
						foreach($pr2 as $v){
							echo "<th> $v </th>";
						}
						echo "<th> $tot2 </th>";
						echo "<th> $r2 </th>";
						echo "</tr>";
					
					echo "
				</table>	

				<br><br>

				<table>
					<center><legend><h1 id = 'pas'><b>&nbsp POSTTEST PART 2 SCORES &nbsp <b/></h1></legend></center>";
						echo  "<tr>";
						for($i=41;$i<=70;$i++)
						echo "<th> Q$i </th>";
						echo "<th> Total </th>";
						echo "<th> Remarks </th>";
						echo "</tr>";

						echo  "<tr>";
						foreach($pr3 as $v){
							echo "<th> $v </th>";
						}
						echo "<th> $tot3 </th>";
						echo "<th> $r3 </th>";
						echo "</tr>";
					
					echo "
				</table>

				<p> <button id='out' type=submit name=buttons value='Go Back'><b>Go Back</b></button>	
				
	";
}
else{
	header('Location:login.php');
}	

?>

