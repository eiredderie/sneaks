<?php 
    session_start();
    require_once('compiled.php');

    if(!isset($_SESSION['loginErr'])){
        $_SESSION['loginErr'] = "";
    }
    if(isset($_POST['submit'])){
        if(login($_POST['email'], $_POST['password'])){
            header("Location: home.php");
        }
        else{
            header("Location: index.php");
        }
    }   
    
    if(isset($_SESSION['id'])){
        //$_SESSION['nameinnav'] = substr($_SESSION['fname'], 0, 1) . substr($_SESSION['lname'], 0, 1);
        $_SESSION['nameinnav'] = $_SESSION['lname'] . ", " . substr($_SESSION['fname'], 0, 1);
    }
    else{
        $_SESSION['nameinnav'] = "LOG IN";
    }
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/4.1.0/cosmo/bootstrap.min.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" id="bootstrap-css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-icons/3.0.1/iconfont/material-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aldrich">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+SC">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Anton">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arsenal">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/newstyles.css">
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/script.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "65%";
            document.getElementById("main").style.marginLeft = "65%";
            document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
            document.getElementById("main").style.marginLeft= "0";
            document.body.style.backgroundColor = "white";
        }
    </script>
    
</head>

<body>
    <div id="flipkart-navbar">
        <div class="container">
            <div class="row row1">
            </div>
            <div class="row row1"></div>
            <div class="row row2">
                <div class="col-sm-2">
                    <h2 style="margin:0px;"><span class="smallnav menu" onclick="openNav()"><img src="assets/img/SHOES-logo-mono.png" width="50" height="50"></span></h2>
                    <h1 style="margin:0px;"><span class="largenav"><a href="index.php" style="color: #fff"><img src="assets/img/SHOES-logo-mono.png" width="50" height="50"><p class="logotext">SNEAKS</p></a></span></h1>
                </div>
                <div class="col-sm-1">
                </div>
                <div class="flipkart-navbar-search smallsearch col-sm-6 col-xs-11">
                    <div class="row">
                        <input class="flipkart-navbar-input col-xs-11" type="text" placeholder="Search for Products, Brands and more" name="">
                        <button class="flipkart-navbar-button col-xs-1">
                            <svg width="15px" height="15px">
                                <path d="M11.618 9.897l4.224 4.212c.092.09.1.23.02.312l-1.464 1.46c-.08.08-.222.072-.314-.02L9.868 11.66M6.486 10.9c-2.42 0-4.38-1.955-4.38-4.367 0-2.413 1.96-4.37 4.38-4.37s4.38 1.957 4.38 4.37c0 2.412-1.96 4.368-4.38 4.368m0-10.834C2.904.066 0 2.96 0 6.533 0 10.105 2.904 13 6.486 13s6.487-2.895 6.487-6.467c0-3.572-2.905-6.467-6.487-6.467 "></path>
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="col-sm-1" style="margin-left: -40px">
                </div>
                <div class="cart largenav col-sm-1 push-right">
                    <a class="cart-button" href="cart.php">
                        <svg class="cart-svg " width="16" height="16 " viewBox="0 0 16 16 ">
                            <path d="M15.32 2.405H4.887C3 2.405 2.46.805 2.46.805L2.257.21C2.208.085 2.083 0 1.946 0H.336C.1 0-.064.24.024.46l.644 1.945L3.11 9.767c.047.137.175.23.32.23h8.418l-.493 1.958H3.768l.002.003c-.017 0-.033-.003-.05-.003-1.06 0-1.92.86-1.92 1.92s.86 1.92 1.92 1.92c.99 0 1.805-.75 1.91-1.712l5.55.076c.12.922.91 1.636 1.867 1.636 1.04 0 1.885-.844 1.885-1.885 0-.866-.584-1.593-1.38-1.814l2.423-8.832c.12-.433-.206-.86-.655-.86 " fill="#fff "></path>
                        </svg>
                        <span class="item-number">0</span>
                    </a>
                </div>
                <?php 
                    if($_SESSION['nameinnav'] == "LOG IN"){
                        echo "<a class='logintext btn btn-link btn-sm pmd-btn-flat pmd-ripple-effect' href='login.php' style='font-size: 16px; margin: 5px;color: #fff;'>" . $_SESSION['nameinnav']. "</a>";
                    }
                    else{
                        echo "<a class='logintext btn btn-link btn-sm pmd-btn-flat pmd-ripple-effect dropdown-toggle' id='menu1' data-toggle='dropdown' style='font-size: 16px; margin: 5px;'>" . $_SESSION['nameinnav'] . "</a>
                        <ul class='dropdown-menu' role='menu' aria-labelledby='menu1'>
                            <li role='presentation'><a role='menuitem' href='account.php' tabindex='-1' href='#'>Profile</a></li>
                            <li role='presentation'><a role='menuitem' tabindex='-1' href='#'>Orders</a></li>
                            <li role='presentation' class='divider'></li>
                            <li role='presentation'><a role='menuitem' href='logout.php' tabindex='-1' href='#'>Logout</a></li>
                        </ul>";
                    }
                ?>
            </div>
            <div class="row row1">
                <ul class="largenav">
                    <li class="upper-links"><a class="links" href="http://clashhacks.in/">Casual Shoes</a></li>
                    <li class="upper-links">|</li>
                    <li class="upper-links"><a class="links" href="https://campusbox.org/">Sports Shoes</a></li>
                    <li class="upper-links">|</li>
                    <li class="upper-links"><a class="links" href="http://clashhacks.in/">Sandals</a></li>
                    <li class="upper-links">|</li>
                    <li class="upper-links"><a class="links" href="http://clashhacks.in/">Boots</a></li>
                    <li class="upper-links">|</li>
                    <li class="upper-links"><a class="links" href="http://clashhacks.in/">Mens Shoes</a></li>
                    <li class="upper-links">|</li>
                    <li class="upper-links"><a class="links" href="http://clashhacks.in/">Womens Shoes</a></li>
                    <li class="upper-links">|</li>
                    <li class="upper-links"><a class="links" href="http://clashhacks.in/">Kids Shoes</a></li>
                    <li class="upper-links">|</li>
                    <li class="upper-links"><a class="links" href="http://clashhacks.in/">Baby Shoes</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div id="mySidenav" class="sidenav">
        <div class="container" style="background-color: #2874f0;">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">X</a>
        </div>
        <a></a>
        <a></a>
        <a href="http://clashhacks.in/">Casual Shoes</a>
        <a href="http://clashhacks.in/">Sports Shoes</a>
        <a href="http://clashhacks.in/">Sandals</a>
        <a href="http://clashhacks.in/">Boots</a>
        <a href="http://clashhacks.in/">Mens Shoes</a>
        <a href="http://clashhacks.in/">Womens Shoes</a>
        <a href="http://clashhacks.in/">Kids Shoes</a>
        <a href="http://clashhacks.in/">Baby Shoes</a>
    </div>
    <div class="login-clean">
        <form method="post" style="background-color:#424949  ;">
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><img src="assets/img/SHOES-logo-mono.png" width="100" height="100"></i></div>
            <div class="form-group"><center><h4><?=$_SESSION['loginErr'] ?></h4></center></div>
            <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email" required></div>
            <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password" required></div>
            <div class="form-group"><button class="btn btn-primary btn-block" role="button" name="submit" type="submit" style="background-color:#FBFCFC;color:#424949;"><strong>LOG IN</strong></button></div>
            <a href="signup.php" class="forgot"><span style="text-decoration: underline;">Don't yet have an account? Sign Up here.</span></a>
            <a class="forgot"><span style="text-decoration: underline;">Forgot your email or password?</span></a>
        </form>
    </div>
    <div class="footer-clean" style="background-color:#424949;padding:32px;">
        <footer>
            <div class="container">
                <div class="row justify-content-center" style="background-color:rgba(251,252,252,0);">
                    <div class="col-sm-4 col-md-3 item" style="padding-right:0;">
                        <h3 style="color:#FBFCFC;">ABOUT US</h3>
                        <ul>
                            <li style="color:#FBFCFC;"><a href="#">Company</a></li>
                            <li style="color:#FBFCFC;">Shipping Information</li>
                            <li style="color:#FBFCFC;">Privacy Policy</li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3 style="color:#FBFCFC;">CONTACT US</h3>
                        <ul>
                            <li><a href="#" style="color:rgb(246,249,251);">España Blvd, Sampaloc, Manila</a></li>
                            <li style="color:#FBFCFC;"><a href="#">406 1611</a></li>
                            <li></li>
                        </ul><a href="#" style="color:#FBFCFC;">sneaks.ph@gmail.com</a></div>
                    <div class="col-lg-3 item social"><a href="#" style="background-color:#424949;"><i class="icon ion-social-facebook" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-twitter" style="color:#FBFCFC;background-color:#424949;"></i></a>
                        <a
                            href="#" style="background-color:#424949;"><i class="icon ion-social-snapchat" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-instagram" style="color:#FBFCFC;"></i></a>
                            <p class="copyright"
                                style="color:#FBFCFC;font-size:21px;">Sneaks © 2018</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</body>

</html>