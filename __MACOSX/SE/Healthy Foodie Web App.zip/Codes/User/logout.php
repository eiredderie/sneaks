<?php
	session_start();
	$_SESSION['access']="true";
	$_SESSION['id']="";
	$_SESSION['msg']="You have successfully logout your account.";
	header('Location:index.php');

?>