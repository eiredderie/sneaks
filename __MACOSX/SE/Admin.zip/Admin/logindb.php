<?php
    session_start();
	if(isset($_POST['login'])){
		$servername = "localhost";
		$username = "id5591164_docgan";
		$password = "docgan@2018";
		$dbName = "id5591164_healthyfoodie";
		
		
		$conn = new mysqli ($servername, $username, $password, $dbName);
		
		$email = $_POST["emaildb"];
		$pass = $_POST["dbpass"];
		$encryptpass=md5($pass);
		$stmt = $conn->prepare("SELECT AdminId FROM admin WHERE Email = ? AND Password = ?");
		$stmt->bind_param("ss",$email,$encryptpass);
		$stmt->execute();
		$stmt->bind_result($results);
		$stmt->fetch();

		if(!$conn){
			echo "Error";
		}
		if($results>=1){
			$_SESSION['access']="true";
			header('Location:dbpage.php');
		}
		else{
			$_SESSION['msg']="Incorrect Email and Password";
			header('Location:index.php');
		}
		$stmt->close();
		$conn->close();
	}
	else{
		header('Location:login.php');
	}

?>