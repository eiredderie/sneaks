<?php
session_start();

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		
	
	$conn = new mysqli ($servername, $username, $password, $dbName);

	$id=$_SESSION['id'];
	$sql = "SELECT Name,Age,Gender,Grade FROM user where ID = ".$id."";
	$result = mysqli_query($conn ,$sql);	
	
	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("Select Remarks from pretestq1 WHERE PretestQ1Id = ?");
	echo $conn->error;
	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($pr1);
    $stmt->fetch();
	
	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("Select Remarks from pretestq2 WHERE PretestQ2Id = ?");
	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($pr2);
    $stmt->fetch();
	
	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("Select Remarks from pretestq3 WHERE PretestQ3Id = ?");
	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($pr3);
    $stmt->fetch();
	
	//posttest
	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("Select Remarks from posttestq1 WHERE PosttestQ1Id = ?");
	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($pt1);
    $stmt->fetch();
	
	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("Select Remarks from posttestq2 WHERE PosttestQ2Id = ?");
	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($pt2);
    $stmt->fetch();
	
	$conn = new mysqli ($servername, $username, $password, $dbName);
	$stmt = $conn->prepare("Select Remarks from posttestq3 WHERE PosttestQ3Id = ?");
	$stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($pt3);
    $stmt->fetch();
	
	
	$conn = new mysqli ($servername, $username, $password, $dbName);
	
	if(!isset($pr1)||$pr1==""){
		$pr1="No Score";
	}
	if(!isset($pr2)||$pr2==""){
		$pr2="No Score";
	}
	if(!isset($pr3)||$pr3==""){
		$pr3="No Score";
	}
	if(!isset($pt1)||$pt1==""){
		$pt1="No Score";
	}
	if(!isset($pt2)||$pt2==""){
		$pt2="No Score";
	}
	if(!isset($pt1)||$pt3==""){
		$pt3="No Score";
	}
	
?>
<!DOCTYPE html>
<html>
    <head>
        
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      
        <title>Healthy Foodie</title>
      	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      	<link rel="stylesheet" href="style2.css">
      	<script src="js/jquery.js"></script>
      	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
      	<link rel="stylesheet" href="css/font-awesome.min.css">

      	<script src="js/imgzoom.min.js"></script>
      	<script src="js/scrollreveal.min.js"></script>
      	<script src="js/countdown.min.js"></script>
        <link rel="stylesheet" href="footer.css">

        <style>
        #pas{
        color: White;
        background-color:#373331;
        width: 50%;
         border-radius: 25px;
         border: 2px ;
        border-style: solid;
        border-color: #251f17;  
        }   
        table{
            background-color: #03cea4;
            border-radius: 9px;
            color: black;  
            border: 3px solid gray;
            width:45%;
        }

        td,tr,th{
            text-align: center;
            font-size: 25px;
            border:none;
        }
      </style>
    </head>
    
    
    
    <body>
        
        <div id="nav">
	  <a class="navbar-brand navbar-link" href="index.php"><img src="logo_HF.png" id="logo"></a>
        <div class="container">
            <div class="pull-left">
                <div id="logo">

                </div>
            </div>
            <div class="pull-right">
                <ul id="navigation">
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="test.php">TESTS</a></li>
                    <li><a href="aboutus.php">ABOUT US</a></li>
                    <li class="active"><a href="account.php">ACCOUNT</a></li>
                    <li><a href="logout.php">LOGOUT</a></li>
                    </ul>
            </div>
            <div class="clear"></div>
        </div>
    </div>

    <br>
	<!--<div id="slider">
		<div class="imgheader" style="background-image: url(slidernew_HF.png);"></div>
	</div>-->
	<br><br><br><br>
	
	<table align="center">
					<center><legend><h1 id = 'pas'><b>&nbsp ACCOUNT DETAILS &nbsp <b/></h1></legend></center>
					<?php
					$names=mysqli_fetch_assoc($result);
					if($names!=NULL){
						$columns=array_keys($names);
						echo "<tr>";
						$result = mysqli_query($conn ,$sql);
						// for ($i = 0; $i < mysqli_num_fields($result); $i++) {
						// echo  "<th>".$columns[$i] . "</th>";
						// }
						// echo "</tr>";
							while($row= mysqli_fetch_row($result))
							{
								for($j=0; $j<mysqli_num_fields($result);$j++)
								{
                  echo  "<th>".$columns[$j] . "</th>";
									if(!isset($row[$j]))
										echo "<td>NULL</td>";
									else
										echo "<td>".$row[$j]."</td>";

                echo "</tr>";
								}
								$row--;
							}   
					}
					else{
						echo "NO DATA";
					}

					?>
				</table>	
				
				<table align="left">
				<tr><th colspan="2"><h2><b>Pre Test Results</b></h2></th></tr>
				<tr><th>Part 1</th><td><?= $pr1?></td></tr>
				<tr><th>Part 2</th><td><?= $pr2?></td></tr>
				<tr><th>Part 3</th><td><?= $pr3?></td></tr>
				</table>
				
				<table align="right">
				<tr><th colspan="2"><h2><b>Post Test Results</b></h2></th></tr>
				<tr><th>Part 1</th><td><?= $pt1?></td></tr>
				<tr><th>Part 2</th><td><?= $pt2?></td></tr>
				<tr><th>Part 3</th><td><?= $pt3?></td></tr>
				</table>

    
    
    </body>
</html>
