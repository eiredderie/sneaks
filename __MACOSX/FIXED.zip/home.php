<?php 
    SESSION_START();
    require_once('compiled.php');
    
    (($_SESSION['username'] == "") ||($_SESSION['fname'] == "") ||($_SESSION['lname'] == "")) ? header("Location: index.php") : null;
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>trial1_sneaks</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/4.1.0/cosmo/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-icons/3.0.1/iconfont/material-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aldrich">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+SC">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Anton">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arsenal">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body style="padding:0px;">
    <nav class="navbar navbar-light navbar-expand-md" style="background-color:#6f7a85;">
        <div class="container-fluid"><a class="navbar-brand text-monospace text-white" href="home.php" style="font-size:30px;color:white;font-family:sans-serif;"><img src="assets/img/SHOES-logo-mono.png" width="50" height="50"><strong>&nbsp;SNEAKS</strong></a><button class="navbar-toggler"
            data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="#"></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" style="font-size:20px;margin:8px;color:rgba(255,255,255,0.5);"><i class="fa fa-search"></i><strong>&nbsp;Search</strong></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link text-capitalize text-white-50 active d-table-cell float-right" href="home.php" style="font-size:20px;font-family:sans-serif;margin-top:8px;color:#FBFCFC;"><i class="fa fa-tags"></i><strong>&nbsp;Products</strong></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link text-monospace text-white-50 d-table-cell float-right" href="cart.php" style="font-size:20px;font-family:sans-serif;margin-top:8px;"><i class="fa fa-shopping-cart"></i><strong>&nbsp;Cart</strong></a></li>
                    <li class="dropdown"><a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" style="margin:0px;font-size:25px;color:rgba(255,255,255,0.5);"><i class="icon ion-android-person" style="font-size:30px;color:rgba(255,255,255,0.5);"></i>&nbsp;<?php echo $_SESSION['fname'] . " " . $_SESSION['lname']?></a>
                        <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="account.php"><strong>Profile</strong></a><a class="dropdown-item" role="presentation" href="index.html"><strong>Log Out</strong></a></div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container" style="height:80px;width:959px;">
        <h1 style="font-family:Anton, sans-serif;color:#424949;padding:21px;font-size:47px;"><i class="material-icons" style="font-size:47px;">shopping_basket</i>&nbsp;SNEAKS PRODUCTS</h1>
    </div>
    <div class="container" style="margin-top:20px;padding:16px;">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-3">
                    <a href="new-arrivals.html">
                        <div class="serviceBox yellow" style="padding:15px;">
                            <div class="service-icon" style="padding:0px;height:48px;width:201px;background-color:#0f067a;margin:-14px;"></div>
                            <h3 style="color:#424949;padding:10px;font-size:32px;font-family:Allerta, sans-serif;padding-top:20px;">NEW ARRIVALS</h3>
                            <div class="service-content" style="width:200px;">
                                <hr style="margin:1px;height:1px;width:130px;">
                                <p></p>
                            </div>
                            <p class="text-center" style="width:182px;margin:-5px;padding:0px;color:#424949;">Shop all the latest&nbsp;<strong>shoes</strong>&nbsp;in the&nbsp;<strong>New Arrivals</strong>&nbsp;section. From our latest collaborations with the hottest athletes and designers, to innovative performance product, SNEAKS
                                has it all.</p>
                        </div>
                    </a>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-3">
                    <a href="kids-boys.html">
                        <div class="serviceBox green" style="padding:0px;">
                            <div class="service-icon"></div>
                            <div class="service-content" style="padding:22.3px;margin:-5px;">
                                <h3 style="color:#424949;padding:10px;font-size:32px;font-family:Allerta, sans-serif;"><strong>KIDS</strong></h3>
                                <hr style="width:161px;">
                                <p class="text-center" style="padding:0px;margin:-5px;">We've got everything from&nbsp;<strong>kids</strong>&nbsp;trainers to&nbsp;designer sandals. For &nbsp;fashion-loving feet, head this way.&nbsp;Find great deals on the latest styles of sneakers, sandals, dress, casual,
                                    and boots for girls and boys.</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-3">
                    <div class="serviceBox pink" style="padding:0px;">
                        <div class="service-icon" style="width:202px;height:52px;"><a href="#"></a></div>
                        <div class="service-content" style="padding:36.5px;">
                            <h3 class="text-left" style="font-size:32px;color:#424949;padding:0px;font-family:Allerta, sans-serif;width:159px;height:61px;margin:-8px;padding-top:0px;"><strong>womens</strong></h3>
                            <hr style="height:1px;padding:0px;margin:11px 3.5px;">
                            <p class="text-center" style="margin:-5px;padding:0px;padding-top:10px;">Shop&nbsp;<strong>women's shoes</strong>&nbsp;at SNEAKS. Find awesome deals on the hottest styles of women's athletics, sandals, boots, and casual.&nbsp;</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-3">
                    <div class="serviceBox green" style="padding:0px;">
                        <div class="d-block float-none service-icon" style="background-color:#424949;height:53px;padding:0px;"><a href="#"></a></div>
                        <div class="service-content" style="padding:9px;">
                            <h3 style="color:#424949;font-size:32px;padding:10px;font-family:Allerta, sans-serif;padding-top:15px;"><strong>mens</strong></h3>
                            <hr style="height:1px;margin:17px 3.5px;padding:0px;">
                            <p class="text-center" style="padding:0px;margin:2px;">Our latest collection of&nbsp;<strong>mens shoes</strong>&nbsp;combines our designers vision with our technical experts invention. With a range of smart and casual silhouettes, our shoes for men use premium materials, wearable
                                colours</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-clean" style="background-color:#424949;padding:32px;">
        <footer>
            <div class="container">
                <div class="row justify-content-center" style="background-color:rgba(251,252,252,0);">
                    <div class="col-sm-4 col-md-3 item" style="padding-right:0;">
                        <h3 style="color:#FBFCFC;">ABOUT US</h3>
                        <ul>
                            <li style="color:#FBFCFC;"><a href="#">Company</a></li>
                            <li style="color:#FBFCFC;">Shipping Information</li>
                            <li style="color:#FBFCFC;">Privacy Policy</li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3 style="color:#FBFCFC;">CONTACT US</h3>
                        <ul>
                            <li><a href="#" style="color:rgb(246,249,251);">España Blvd, Sampaloc, Manila</a></li>
                            <li style="color:#FBFCFC;"><a href="#">406 1611</a></li>
                            <li></li>
                        </ul><a href="#" style="color:#FBFCFC;">sneaks.ph@gmail.com</a></div>
                    <div class="col-lg-3 item social"><a href="#" style="background-color:#424949;"><i class="icon ion-social-facebook" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-twitter" style="color:#FBFCFC;background-color:#424949;"></i></a>
                        <a
                            href="#" style="background-color:#424949;"><i class="icon ion-social-snapchat" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-instagram" style="color:#FBFCFC;"></i></a>
                            <p class="copyright"
                                style="color:#FBFCFC;font-size:21px;">Sneaks © 2018</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>