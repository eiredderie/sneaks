<?php
session_start();
$_SESSION['q_no']=0;
header("Location:pretest.php");
?>