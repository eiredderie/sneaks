<?php

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
	
	
	
	$name = $_POST["name"];
	$age = $_POST["age"];
	$gender = $_POST["gender"];
	$grade = $_POST["grade"];
	$uname = $_POST["uname"];
	$upass = $_POST["upass"];
	$type = $_POST["type"];

	$conn = new mysqli ($servername, $username, $password, $dbName);
	if(!$conn){
			die("Connection Failed. ".mysqli_connect_error);
	}
	
	$stmt = $conn->prepare("SELECT Id FROM account WHERE Username = ?");
	$stmt->bind_param("s",$uname);
	$stmt->execute();
	$stmt->bind_result($results);
	$stmt->fetch();

	if(!$conn){
			$_SESSION['rmsg']="Website is down";
			header('Location:login.php');
	}
	if($results>=1){
		session_start();
		$_SESSION['rmsg']="Username already taken";
		header('Location:register.php');
	}
	else{
		$_SESSION['rmsg']="";
		$id=0;
		$prog="pretest";
		$encryptedpass=md5($upass);
		$sql = "INSERT INTO account (Username, Password, Type, Progress) 
				VALUES ('".$uname."','".$encryptedpass."','".$type."','".$prog."')";
		$result = mysqli_query($conn ,$sql);

		$pstmt = $conn->prepare("SELECT Id FROM account WHERE Username = ?");
		$pstmt->bind_param("s",$uname);
		$pstmt->execute();
		$pstmt->bind_result($id);
		$pstmt->fetch();

		$sql2 = "INSERT INTO user (Id, Uname, Age, Gender, Grade) 
				VALUES ('".$id."','".$name."','".$age."','".$gender."','".$grade."')";
		$result2 = mysqli_query($conn ,$sql2);


		header('Location:create.php?id='.$id.'.&name='.$name.'&age='.$age.'&gender='.$gender.'&grade='.$grade.'');

	}
	
?>