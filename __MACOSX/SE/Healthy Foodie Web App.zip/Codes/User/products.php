
<!DOCTYPE html>
<html>
    <head>
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      
        
	<title>PurryTails</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="style2.css">
	<script src="js/jquery.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<script src="js/imgzoom.min.js"></script>
	<script src="js/scrollreveal.min.js"></script>
	<script src="js/countdown.min.js"></script>
        
        
        
        
    </head>
    <body>
        
         <!-- Modal content-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">EARTHBORN (&#8369;539.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/food/1.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>This helps condition your dog for life, with quality animal proteins such as chicken meal and whitefish meal, which aid in building and maintaining your dogs lean muscle mass. Formulated with high-quality ingredients, vitamins, and minerals, Adult Vantage provides excellent digestibility and nutrient absorption.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">BE HAPPY (&#8369;749.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/food/2.jpg">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Has proper levels of calcium and phosphorous help ensure that your dog will get the right mineral balance to build strong teeth and bones. Beta-carotene, along with fruits and vegetables such as blueberries and carrots, help support a healthy immune system. Easily-digested grains such as oatmeal, barley, brown rice, and rye provide natural fiber to maintain a healthy intestinal tract.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">BENEFUL (&#8369;669.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/food/3.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>With L-carnitine, your dogs body will turn into a lean, mean working machine, as it helps convert body fat into muscle and energy, supporting your dogs lean muscle mass and overall body conditioning. Balanced omega-6 and omega-3 fatty acids support a healthy coat and skin. Adult Vantage is 100% guaranteed for taste and nutrition, for the maintenance of adult dogs.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal4" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">FEEDWELL (&#8369;697.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/food/4.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Offers optimal holistic nutrition, which fulfills the special needs of growing puppies. Feedwell puppies contains DHA, a type of long-chain Omega-3 fatty acid that is present in concentrations in brain and retinal tissue and aids in healthy brain and eye development and function in puppies.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal5" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">PEDIGREE (&#8369;920.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/food/5.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Made with our high-quality ingredients and processing technologies, Small Breed provides excellent digestibility and nutrient absorption. Small Breed is 100% guaranteed for taste and nutrition for adult dogs.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal6" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Friskies (&#8369;940.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/food/6.jpg">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Friskies is advanced alternative nutrition for cats. We've combined the highest quality holistic ingredients to nourish your cat. We've selected the finest proteins, fats, fruits and vegetables, along with a complex blend of vitamins and minerals to support energy, immunity, health and wellness. Every ingredient has a unique purpose and is carefully balanced to provide maximum benefit and nutrition.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal7" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">COMPLETE (&#8369;540.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/food/7.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>With Complete, quality animal and fish proteins such as chicken meal, herring meal, salmon meal and whitefish meal help build and maintain muscle is guaranteed. Balanced levels of calcium and phosphorus help build strong bones and teeth.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal8" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">CANIDAE (&#8369;599.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/food/8.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Canidae had guaranteed levels of antioxidant nutrients like Vitamin E and Vitamin C blended with nutrient-rich vegetables and fruits such as peas, apples, blueberries, carrots, spinach and cranberries help support the immune system, good digestion and intestinal health.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal9" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">SOLID GOLD (&#8369;620.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/food/9.jpg">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Cats love the great taste and smell of fish. Salmon meal and herring meal are rich in omega fatty acids. These protein sources are highly digestible and help your cat maintain top condition and overall good health. Quality fish and animal proteins help build and maintain lean muscle mass. Balanced levels of calcium and phosphorus promote strong bones and teeth.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal10" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">IAMS (&#8369;450.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/food/10.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Made without grain or gluten, this special formula is great as a grain-free diet. It is highly digestible with a great natural fish flavor cats love. Wild Sea Catch is 100% guaranteed for taste and nutrition.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal11" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">GREEN PLASTIC TOY (&#8369;240.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/toys/t1.jpg">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>The designs from GPT are cute and whimsical, and they're also environmentally savvy. The rubber toys are made with Zogoflex, a tough, buoyant, and fully recyclable material that is also non-toxic, both BPA and phthalate-free. In other words, strong and safe!</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal12" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">BLUE AND WHITE PLASTIC BONE (&#8369;300.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/toys/toy2.jpeg">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Tough yet tender toys for dogs. These fun-shaped bone, built for dogs who play hard, our durable Zogoflex® dog toys bounce, float, go in the dishwasher—and recycle back into new Zogoflex®.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal13" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">GRAY AND BLUE CHEWABLE (&#8369;350.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/toys/toy3.jpeg">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Designed for dogs that have an intense play drive and love to be active on land, in the water, chasing, and fetching. The durable and subtle squish makes these dog toys great for dogs of all ages.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal14" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">BROWN MINI COUCH (&#8369;2399.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/bed/c1.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Super soft and cozzy, this Brown mini couch allows your pet to snooze in style! It is a lovely warm and comfortable resting area for your four-legged friend with deep filled fiber sides to provide extra comfort and security and a drop down front for easy access.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal15" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">WILDCAT BLACK BED (&#8369;2239.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/bed/c2.jpg">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>This brilliant Wildcat black bed offers a personal sanctuary for your pet but with way more style!  It has been designed to provide a fabulous place for your four-legged friend to curl up and relax or snooze. The plastic house, on its strong and sturdy stand, offers your pet a great view and you will love how it complements your home decor.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal16" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">BLACK MINI BED (&#8369;1949.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/bed/c3.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Hailed as the best quality vet bedding in Europe, This black mini bed is a hygienic, non-irritant and non-allergenic veterinary dry bed made from deep pile to provide a high level of heat retention. With a double-woven backing that makes it harder to chew, Bronte Glen traditional vet bedding is autoclave machine washable at 90deg, can be washed outside with a Jetwash, and can be either tumble or drip-dried.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal17" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">DOG LEOPARD BED (&#8369;2239.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/bed/d1.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>This brilliant Dog leopard bed offers a personal sanctuary for your pet but with way more style!  It has been designed to provide a fabulous place for your four-legged friend to curl up and relax or snooze. The plastic house, on its strong and sturdy stand, offers your pet a great view and you will love how it complements your home decor.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal18" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">LIGHT BROWN SOFT BED (&#8369;1239.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/bed/d2.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Synonymous with comfort, this Light brown soft bed features an ultra-plush, microtech sleep surface to keep your pet super warm and snug. It is the perfect cosy bed for your dog or pup to relax and sleep on. No more having to sit or lie on a cold plastic tray at the bottom of a dog cage or crate with this sumptuous crate mat!</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal19" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">PRINCESS GRAY BED (&#8369;2800.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/bed/d3.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Looking for the perfect snug bed for your pet? This princess gray bed is warm, super soft and comfortable for your four-legged friend. The luxurious, soft faux fur lining with a soft faux suede outer, makes this very stylish dog bed warm, super soft and comfortable for your canine friend.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal20" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">BABY BLUE HOODIE (&#8369;550.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/dress/dc1.jpg">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Bundle up your dog in style in the baby blue hoodie. This reversible hoodie features a reflective label, 3M reflective piping, leash access welt slit, hook & loop closure, and water repellent ripstop quilted jacket.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal21" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">FUCHSIA POLO SHIRT (&#8369;630.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/dress/dc2.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>The bright fuchsia scream summertime! This fun shirt provides protection with UPF 40. Made from 100% cotton.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal22" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">SANTA'S BABY RED DRESS (&#8369;700.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/dress/dc3.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>This precious dress is a must have for your diva this holiday season! Features sparkly crystal appliques, white bow with pom pom detail, and matching hat included. Doubles as a harness with a built-in D-ring. Velcro closure. 50% cotton, 50% polyester.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal23" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">WILD ZEBRA WITH PURPLE HIGHLIGHTS (&#8369;830.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/dress/dc4.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>The perfect top for this Spring/Summer season! These cute zebra stripes dog tops feature lace frills, pearl beads, and logo embroidery. Hand wash with care.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
  <!-- Modal content-->
  <div class="modal fade" id="myModal24" role="dialog">
    <div class="modal-dialog">
	 <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">ANGRY MOB HALLOWEEN COSTUME (&#8369;1500.00)</h4>
        </div>
          <div class="row">
            <div class="col-md-6">
             <img src="img/dress/dc5.png">
            </div>
            <div class="col-md-5">
              <h2>Description</h2>
			  <p>Brown and white angry mob costume for dogs, complete with commoner’s hat. 20% cotton and 80% polyester.</p>
			  Product Quantity 
			  <select name="amount">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              </select>
			  <button type="button" class="btn btn-default btn-sm" id="what">
			  <span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
              </button>
            </div>
          </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
  </div>
    <!-- Main Page-->
	<div id="nav">
	  <a class="navbar-brand navbar-link" href="#"><img src="logo.png" id="logo"></a>
		<div class="container">
			<div class="pull-left">
				<div id="logo">

				</div>
			</div>
			<div class="pull-right">
				<ul id="navigation">
					<li><a href="index.html">HOME</a></li>
					<li class="active"><a href="products.html">PRODUCTS</a></li>
					<li><a href="pets.html">PETS</a></li>
					<li><a href="services.html">SERVICES</a></li>
					<li><a href="about.html">ABOUT US</a></li>
                                        <li id="cart"><a href="http://localhost:8080/Online_Shopping/shopcart.jsp"><i class="glyphicon glyphicon-shopping-cart"></i></a></li>
				</ul>
			</div>
			<div class="clear"></div>
		</div>
	</div>
	<div id="slider">
		<div class="imgheader" style="background-image: url(bgace.jpg);"></div>
	</div>
	<div id="main">
		<div class="container">
			<div class="row mgb50" style="position: relative;">
				<div class="col-md-12">
					<h2>Products</h2>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal"><img src="img/food/1.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>EARTHBORN</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal2"><img src="img/food/2.jpg" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>BE HAPPY</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal3"><img src="img/food/3.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>BENEFUL</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal4"><img src="img/food/4.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>FEEDWELL </h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal5"><img src="img/food/5.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>PEDIGREE</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal6"><img src="img/food/6.jpg" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>FRISKIES</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal7"><img src="img/food/7.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>COMPLETE</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal8"><img src="img/food/8.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>CANIDAE</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal9"><img src="img/food/9.jpg" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>SOLID GOLD</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal10"><img src="img/food/10.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>IAMS</h3>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal11"><img src="img/toys/t1.jpg" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>GREEN PLASTIC TOY</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal12"><img src="img/toys/toy2.jpeg" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>BLUE AND WHITE PLASTIC BONE</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal13"><img src="img/toys/toy3.jpeg" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>GRAY AND BLUE CHEWABLE</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal14"><img src="img/bed/c1.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>BROWN MINI COUCH </h3>
						</div>
					</div>
				</div><div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal15"><img src="img/bed/c2.jpg" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>WILDCAT BLACK BED</h3>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal16"><img src="img/bed/c3.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>BLACK MINI BED</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal17"><img src="img/bed/d1.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>DOG LEOPARD BED</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal18"><img src="img/bed/d2.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>LIGHT BROWN SOFT BED</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal19"><img src="img/bed/d3.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>PRINCESS GRAY BED</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal20"><img src="img/dress/dc1.jpg" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>BABY BLUE HOODIE</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal21"><img src="img/dress/dc2.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>FUCHSIA POLO SHIRT</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal22"><img src="img/dress/dc3.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>SANTA'S BABY RED DRESS</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal23"><img src="img/dress/dc4.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>WILD ZEBRA WITH PURPLE HIGHLIGHTS</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 srfx">
					<div class="prod">
							<div class="thumb">
								<a data-toggle="modal" href="#myModal24"><img src="img/dress/dc5.png" alt=""></a>
							</div>
						<div class="prod-text">
							<h3>ANGRY MOB HALLOWEEN COSTUME</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- DONT REMOVE THIS LINE -->
	<div id="footer-dynamic"></div>
	<script src="js/footer.js"></script>
	<script>
		$(document).ready(function() {
			var navheight = $('#nav').outerHeight(true);
			var imgheight = $(window).height();
			$('body').css('padding-top', navheight);

			window.sr = ScrollReveal({duration:'800', distance:'5em', delay:100});
			sr.reveal('#timer-inner');
			sr.reveal('.srfx',{origin: 'right'}, 120);
			sr.reveal('.sfa', {origin: 'right'}, 60);

			// COUNTDOWN
			$("#timercountdown").countdown("2017/02/24", function(event) {
				var $this = $(this).html(event.strftime('' +
				    '<div class="hms">%D<h2>Days</h2></div>' +
				    '<div class="hms">%H<h2>Hour</h2></div>' +
				    '<div class="hms">%M<h2>Minutes</h2></div>' +
				    '<div class="hms">%S<h2>Seconds</h2></div>'
			    ));
			});
			// END COUNTDOWN
		});
	</script>
        
        
        
    </body>
</html>
