<?
session_start();
if(isset($_POST['pretest'])){
	if (isset($_POST['q'.$i])) {
      $_SESSION['q'.$i]=$_POST['q'.$i];
    }
	$_SESSION['q_no']+=1;
	header("Location:pretest.php");
}
else{
	if(isset($_SESSION['q_no']))
		$_SESSION['q_no']=$_SESSION['q_no'];
	else
		$_SESSION['q_no']=0;
}


?>