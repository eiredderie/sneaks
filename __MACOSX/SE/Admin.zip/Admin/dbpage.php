<?php
session_start();
if(isset($_POST['buttons'])){
	if($_POST['buttons']=="Export"){
		header('Location:exportscore.php');
	}
	else if($_POST['buttons']=="Student"){
		header('Location:viewstudents.php');
	}
	else if($_POST['buttons']=="Quiz"){
		header('Location:quiz.php');
	}
	else{
		header('Location:logout.php');
	}
}

if(isset($_SESSION['access'])){
	echo "
		<!DOCTYPE html>
		<html>
		<head>
		<meta charset='ISO-8859-1'>
		<title>HEALTHY FOODIE</title>
		</head>
		<style>

		body {
			background-image:url('background2.jpg');
		    background-size: 100%;
		    background-repeat: repeat;
		    font-family: Arial Narrow;
		    background-color: brown;
		    font-size: 20px;
		 	
		}
		fieldset, h1 {
			background-color: white;
			border: 1px solid black;
			border-radius: 25px;
			color: #f2da94;
		}
		button{
			padding: 15px 30px;
			font-size: 20px;
			background-color: brown;
			background-color: #eeb063;
		}
		fieldset{
			background-color : #8c2a27;
		}
		#pas {
			color: #c74535;
			background-color: #eeb063;
		}
		#out{
			font-size: 15px;
			padding: 10px 20px;
		}
		</style>
		<body>
			<center><img src='header.png' class='img-responsive' height='300' width='600' >

			<br><br>
			
			<form action='dbpage.php' method='POST'>
			
			
			
			<center><fieldset> 
			
				<table>
					<center><legend><h1 id = 'pas'><b>&nbsp DATABASE &nbsp <b/></h1></legend></center>
					<tr> <td><br></td></tr>
					<tr> <td><center><button type=submit name=buttons value='Student'><b>View Student's Results</b></button></center></td>
					<tr> <td><br></td></tr>
					<tr> <td><center><button type=submit name=buttons value='Export'><b>Export</b></button></center></td>
					<tr> <td><br></td></tr>
					<tr> <td><center><button type=submit name=buttons value='Quiz'><b>Quiz Options</b></button></center></td>
				</table>	
				<br><br>
				<p> <button id='out' type=submit name=buttons value='Submit'><b>Logout</b></button>

			</fieldset></center>
			</form>
		</body>
		</html>

		</form>
		</body>
	";
}
else{
	header('Location:login.php');
}


?>