﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour {

	// Use this for initialization
	public void PlayGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    public void nextScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void backScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
    }

    public void goToTitle()
    {
        SceneManager.LoadScene("Title");
    }

    public void goToMenu()
    {
        SceneManager.LoadScene("Menu");
    }

    public void goToEnd()
    {
        SceneManager.LoadScene("End");
    }

    public void goToGo()
    {
        SceneManager.LoadScene("Go Food");
    }

    public void goToGrow()
    {
        SceneManager.LoadScene("Grow Food");
    }

    public void goToGlow()
    {
        SceneManager.LoadScene("Glow Food");
    }

    public void goToGreen()
    {
        SceneManager.LoadScene("Green Food");
    }

    public void goToYellow()
    {
        SceneManager.LoadScene("Yellow Food");
    }

    public void goToRed()
    {
        SceneManager.LoadScene("Red Food");
    }

    public void goToPlate()
    {
        MusicPlayer.PlayDragMusic();
        SceneManager.LoadScene("FoodPlate");
    }

    public void goToPyramid()
    {
        MusicPlayer.PlayDragMusic();
        SceneManager.LoadScene("FoodPyramid");
    }

    public void goToGGG()
    {
        SceneManager.LoadScene("IntroGGG");
    }

    public void goToTraffic()
    {
        SceneManager.LoadScene("IntroTraffic");
    }

    public void goToIntro()
    {
        SceneManager.LoadScene("Introduction");
    }
















}
