﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace UnityWebGLSpeechSynthesis
{
    public class Example03ProxyManagement : MonoBehaviour
    {
        /// <summary>
        /// Reference to the proxy
        /// </summary>
        private ISpeechSynthesisPlugin _mSpeechSynthesisPlugin = null;

        public Button _mButtonCloseBrowserTab = null;

        public Button _mButtonCloseProxy = null;

        public Button _mButtonLaunchProxy = null;

        public Button _mButtonOpenBrowserTab = null;

        public Button _mButtonSetProxyPort = null;

        public InputField _mInputPort = null;

        // Use this for initialization
        IEnumerator Start()
        {
            // get the singleton instance
            _mSpeechSynthesisPlugin = ProxySpeechSynthesisPlugin.GetInstance();

            // check the reference to the plugin
            if (null == _mSpeechSynthesisPlugin)
            {
                Debug.LogError("Proxy Speech Detection Plugin is not set!");
                yield break;
            }

            // proxy has to launch before being available
            if (_mButtonLaunchProxy)
            {
                _mButtonLaunchProxy.onClick.AddListener(() =>
                {
                    _mSpeechSynthesisPlugin.ManagementLaunchProxy();
                });
            }

            // wait for plugin to become available
            while (!_mSpeechSynthesisPlugin.IsAvailable())
            {
                yield return null;
            }

            if (_mButtonCloseBrowserTab)
            {
                _mButtonCloseBrowserTab.onClick.AddListener(() =>
                {
                    _mSpeechSynthesisPlugin.ManagementCloseBrowserTab();
                });
            }

            if (_mButtonCloseProxy)
            {
                _mButtonCloseProxy.onClick.AddListener(() =>
                {
                    _mSpeechSynthesisPlugin.ManagementCloseProxy();
                });
            }

            if (_mButtonOpenBrowserTab)
            {
                _mButtonOpenBrowserTab.onClick.AddListener(() =>
                {
                    _mSpeechSynthesisPlugin.ManagementOpenBrowserTab();
                });
            }

            if (_mButtonSetProxyPort &&
                _mInputPort)
            {
                _mButtonSetProxyPort.onClick.AddListener(() =>
                {
                    int port;
                    if (int.TryParse(_mInputPort.text, out port))
                    {
                        _mSpeechSynthesisPlugin.ManagementSetProxyPort(port);
                    }
                    else
                    {
                        _mInputPort.text = "83";
                    }
                });
            }
        }
    }
}
