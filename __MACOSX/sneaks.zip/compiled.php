<?php 
	
	$servername = 'localhost';
	$user = 'root';
	$pass = '';
	$db = 'sneaks';

	$conn = new mysqli($servername, $user, $pass, $db) or die("Unable to connect");

	function login($email, $password){
		
        $stmt = $GLOBALS['conn']->prepare("SELECT UserID, U_FirstName, U_MiddleName, U_LastName FROM Users WHERE U_Email = ? AND U_Password = ?");
        $encryptpass=md5($password);
        $stmt->bind_param("ss",$email, $encryptpass);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
                $_SESSION['loginErr']="Incorrect Username and Password".$email." ".$password;
                return false;
            
            }
            else{
                while($row = $result->fetch_assoc()){
                    $_SESSION['id'] = $row['UserID'];
                    $_SESSION['fname'] = $row['U_FirstName'];
                    $_SESSION['mname'] = $row['U_MiddleName'];
                    $_SESSION['lname'] = $row['U_LastName'];
                    
                    $_SESSION['loginErr']="Login Successfully";
		
                }

                return true;
            }
        }
        else{
            return false;
        }
}


	function signup($uname, $fname, $lname, $mname, $email, $pass, $contact, $address){

		$stmt = $GLOBALS['conn']->prepare("SELECT UserID FROM Users WHERE U_Email = ? OR U_Username = ?");
		$stmt->bind_param("ss",$email,$uname);
		$stmt->execute();
		$stmt->bind_result($result);
		$stmt->fetch();

		if($result>=1){
            $_SESSION['signupErr']="Username/Email already used in another account.";
            return false;
		}
		else{
			$stmt = $GLOBALS['conn']->prepare("INSERT INTO Users (U_FirstName, U_MiddleName, U_LastName, U_Username, U_Password, U_Email, U_Contact, U_AccountType, U_Address) 
				VALUES (?,?,?,?,?,?,?,?,?)");
            $type="USER";
            $encrpytpass = md5($pass);
			$stmt->bind_param("sssssssss", $fname, $mname, $lname, $uname, $encrpytpass, $email, $contact, $type, $address);
			$stmt->execute();

			//CONFIRMATION FOR EMAIL TO BE ADDED

			$_SESSION['signupErr']="Sign Up Successful.";
            return true;
		}
	}


	//SORT

	function displaySort($column, $order){


		$stmt = "SELECT * FROM items ORDER BY ".$column." ".$order; 
		$result = @mysqli_query($GLOBALS['conn'] ,$stmt);

		while($row = mysqli_fetch_array($result)) {
			$ids[] = $row['ItemID'];
			$brands[] = $row['I_Brand'];
			$types[] = $row['I_Type'];
			$names[] = $row['I_Name'];
			$prices[] = $row['I_Price'];
			$stocks[] = $row['I_Stock'];
			$images[] = $row['I_Image'];
			$gender[] = $row['I_Gender'];
			$desc[] = $row['I_Description'];
			$date[] = $row['AddedDate'];
		}
		return array($ids, $brands, $types, $names, $prices, $stocks, $images, $desc);
    }
    
    //DISPLAYS

    function displayGender($gender){
        
		
		$stmt = $GLOBALS['conn']->prepare("SELECT * FROM items WHERE I_Gender = ?");
        $stmt->bind_param("s", $gender);
        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                while($row = $result->fetch_assoc()){
                    $returnarray[] = array(
                        $row['ItemID'],
                        $row['I_Brand'],
                        $row['I_Type'],
                        $row['I_Name'],
                        $row['I_Price'],
                        $row['I_Stock'],
                        $row['I_Image'],
                        $row['I_Gender'],
                        $row['I_Description'],
                        $row['AddedDate']
                    );
                }

                return $returnarray;
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
		return array($ids, $brands, $types, $names, $prices, $stocks, $images, $gender, $desc, $date);
    }

    
    function displayGenderType($gender, $type){

		$stmt = $GLOBALS['conn']->prepare("SELECT * FROM items WHERE I_Gender = ? AND I_Type = ?");
        $stmt->bind_param("ss", $gender,$type);
        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                while($row = $result->fetch_assoc()){
                    $returnarray[] = array(
                        $row['ItemID'],
                        $row['I_Brand'],
                        $row['I_Type'],
                        $row['I_Name'],
                        $row['I_Price'],
                        $row['I_Stock'],
                        $row['I_Image'],
                        $row['I_Gender'],
                        $row['I_Description'],
                        $row['AddedDate']
                    );
                }

                return $returnarray;
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
		return array($ids, $brands, $types, $names, $prices, $stocks, $images, $gender, $desc, $date);
    }
    
    function displayItem($id, $brand, $type, $name, $price, $stock, $image, $gender, $desc, $date){
        return '
        

                    <div class="item-container">
                        <img src="'.$image.'" width="200" height="200">
                        <p class="item-name">'.$name.'</p>
                        <p class="item-price">₱ '.$price.'</p>
                        <button class="item-button btn btn-danger" data-target="#'.$id.'" id="view" data-toggle="modal">BUY NOW</button>
                    </div>
        
                    <div class="modal fade" id="'.$id.'" role="dialog">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" style="font-family:Bitter, serif;font-size:40px;"> '.$brand.' </h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <h4 class="modal-title" style="font-family:Anton, sans-serif;font-size:30px;margin-left:10px;"> '.$name.' <br></h4>
                                    <h4 class="modal-title" style="font-size:20px;margin:0px;margin-left:10px;padding:10px;padding-top:0px;">
                                        <strong> '.$desc.' </strong><br>
                                    </h4>
        
                                    <div class="col-md-6 column-media">
                                        <img class="img-fluid" src="'.$image.'" alt="Lorem" style="width:280px;height:300px;margin-left:30px;">
                                    </div>
                                    <div class="col-md-6 column-text">
                                        <h1 style="font-family:Bitter, serif;margin-top:10px;margin-bottom:10px;"><strong>PHP '.$price.'</strong>
                                        </h1>
                                        <select name="size">
                                            <option value="" selected="">Size</option>
                                            <optgroup label="Baby (Sizes Newborn - 4)"><option value="">2 M</option> <option value="">3 M</option><option value="">4 M</option></optgroup>
                                            <optgroup label="Walker (Sizes 4.5 - 7)"><option value="">5 M</option> <option value="">6 M</option><option value="">7 M</option></optgroup>
                                            <optgroup label="Toddler"> <option value="">8 M</option><option value="">9 M</option><option value="">10 M</option>  <option value="12">11 M</option><option value="13">12 M</option></optgroup>
                                            <optgroup label="Little Kid (Sizes 12.5 - 3)"><option value="14">13 M</option> <option value="">1 M</option><option value="">2 M</option><option value="">3 M</option></optgroup>
                                            <optgroup label="Big Kids (Sizes 3.5 - 7)"> <option value="">4 M</option><option value="">5 M</option><option value="">6 M</option><option value="">7 M</option></optgroup>
                                        </select>
                                        <input type="number" name="order" placeholder="No. of Order" style="width:98px;margin:10px;margin-left:20px;">
                                        <div class="btn-toolbar"></div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button class="btn btn-primary" type="submit" name="item" value="'.$id.'" style="background-color:#424949;"><strong>ADD TO CART</strong></button>
                                </div>
                            </div>
                        </div>
                    </div>
        
        ';
        }

	//IDDISPLAY
	function displayItemId($id){

		$stmt = $GLOBALS['conn']->prepare("SELECT * FROM items WHERE ItemID = ?"); 
		$stmt->bind_param("i",$id);
		$stmt->execute();
		$stmt->bind_result($ids, $brands, $types, $names, $prices, $stocks, $images);
		$stmt->fetch();

		return array($ids, $brands, $types, $names, $prices, $stocks, $images);
	}

	 function navigate($filename){
        header('Location: $filename');
    }

    //IMPORTANT: Create products folder for image store.
    //IMPORTANT: Change default Image Name.
    //Admin Use. Adds Item to Database. Returns true if upload successful, else false.
    function addItem($brand, $type, $name, $price, $stock, $imagename, $imagetmploc){
        if($imagename != NULL){
        	$seperate = explode(".", $imagename);
        	$filetype = end($seperate);
            $imagenamefinal = "Product." . $filetype;
           	$location = "products/" . $imagenamefinal;
        	move_uploaded_file($imagetmploc, $location);
        }

        $stmt = $GLOBALS['conn']->prepare("INSERT INTO items(I_Brand, I_Type, I_Name, I_Price, I_Stock, I_Image) 
            VALUES(?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssii", $brand, $type, $name, $price, $stock, $location);

        return $stmt->execute();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin Use. Edit Item in Database. Returns true if update successful, else false.
    function editItem($itemid, $brand, $type, $name, $price){
        $stmt = $GLOBALS['conn']->prepare("UPDATE items SET I_Brand=?, I_Type=?, I_Name=?, I_Price=? WHERE ItemID=?");
        $stmt->bind_param("sssii", $brand, $type, $name, $price, $itemid);
        
        return $stmt->execute();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin Use. Delete Item in Database. Takes ItemID as parameter. 
    //Returns true if update successful, else false.
    function deleteItem($itemid){
        $stmt = $GLOBALS['conn']->prepare("DELETE FROM items WHERE ItemID=?");
        $stmt->bind_param("i", $itemid);  


        return $stmt->execute();
        $stmt->close();
        $GLOBALS['conn']->close();
    }
    //Admin and User Use. Gets details of Item. Takes ItemID as parameter. Returns JSON value for Item Details. 
    //Returns Error value of 0 if empty, 1 if Error.
    function getItem($itemid){
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM items WHERE ItemID=?");
        $stmt->bind_param("i", $itemid);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                return json_encode($result->fetch_assoc());
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
        
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin and User Use. Searches for Items depending on keyword parameter. Returns JSON Items.
    //Returns Error value of 0 if empty, 1 if Error.
    function searchItem($keyword){
        $returnarray = array();
        $likekeyword = '%' . htmlspecialchars($keyword) . '%';
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM items WHERE (I_Brand || I_Type || I_Name) LIKE ?");
        $stmt->bind_param("s", $likekeyword);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                while($row = $result->fetch_assoc()){
                    array_push($returnarray, array(
                        "Brand" => $row['I_Brand'],
                        "Type" => $row['I_Type'],
                        "Name" => $row['I_Brand'],
                        "Price" => $row['I_Price'],
                        "Image" => $row['I_Image']
                    ));
                }

                return json_encode($returnarray);
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
    }

    //Admin and User Use. Searches for Items depending on keyword parameter. Returns JSON Items.
    //Returns Error value of 0 if empty, 1 if Error.
    function displayItemsCat($category){
        $returnarray = array();
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM items WHERE I_Type=?");
        $stmt->bind_param("s", $category);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                while($row = $result->fetch_assoc()){
                    array_push($returnarray, array(
                        "Brand" => $row['I_Brand'],
                        "Type" => $row['I_Type'],
                        "Name" => $row['I_Brand'],
                        "Price" => $row['I_Price'],
                        "Image" => $row['I_Image']
                    ));
                }

                return json_encode($returnarray);
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
    }

    //Admin and User Use. Searches for Items depending on keyword parameter. Returns JSON Items.
    //Returns Error value of 0 if empty, 1 if Error.
    function displayItems(){
        $returnarray = array();
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM items");

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                while($row = $result->fetch_assoc()){
                    array_push($returnarray, array(
                        "Brand" => $row['I_Brand'],
                        "Type" => $row['I_Type'],
                        "Name" => $row['I_Brand'],
                        "Price" => $row['I_Price'],
                        "Image" => $row['I_Image']
                    ));
                }

                return json_encode($returnarray);
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
    }

    //Admin Use. Confirms order. Returns true if update successful, else false. Emails Customer for Updates.
    function confirmOrder($orderid){
        $stmt = $GLOBALS['conn']->prepare("UPDATE orders SET Status=? WHERE OrderID=?");
        $stmt->bind_param("si", "CONFIRMED", '$orderid');


        return $stmt->execute();
        //email User
        //mail();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin Use. Declines order. Returns true if update successful, else false. Emails Customer for Updates.
    function declineOrder($orderid){
        $stmt = $GLOBALS['conn']->prepare("UPDATE orders SET Status=? WHERE OrderID=?");
        $stmt->bind_param("si", "DECLINED", '$orderid');


        return $stmt->execute();
        //email User
        //mail();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //User Use. Cancels order. Returns true if update successful, else false. Emails Admin for Updates.
    function cancelOrder($orderid){
        $stmt = $GLOBALS['conn']->prepare("UPDATE orders SET Status=? WHERE OrderID=?");
        $stmt->bind_param("si", "CANCELLED", '$orderid');

        return $stmt->execute();
        //email Admin
        //mail();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin Use. Add Stocks in Database. Gets number and ItemID as parameter. 
    //Returns true if update successful, else false.
    function addStocks($incrementNumber, $itemid){
        //$stmt = $GLOBALS['conn']->prepare("UPDATE items SET I_Stock = ? WHERE ItemID=?");
        $stmt = $GLOBALS['conn']->prepare("UPDATE items SET I_Stock += ? WHERE ItemID=?");
        $stmt->bind_param("ii", $incrementNumber, $itemid);

        return $stmt->execute();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin and User Use. Gets Order Details. Returns JSON value. 
    //Returns Error value of 0 if empty, 1 if Error.
    function getOrder($orderid){
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM orders WHERE OrderID=?");
        $stmt->bind_param("i", $orderid);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                return json_encode($result->fetch_assoc());
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
        
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin Use. Gets Confirmed and Pending Orders. Returns JSON list.
    //Returns Error value of 0 if empty, 1 if Error.
    function adminOrders(){
        $returnarray = array();
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM orders WHERE (Status = 'CONFIRMED') || (Status = 'PENDING') ORDER BY Status");

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                while($row = $result->fetch_assoc()){
                    array_push($returnarray, array(
                        "OrderID" => $row['OrderID'],
                        "Date" => $row['Date'],
                        "Time" => $row['Time'],
                        "Items" => $row['Items'],
                        "Quantity" => $row['Quantity'],
                        "Total" => $row['Total'],
                        "Status" => $row['Status'],
                        "Contact" => $row['Contact'],
                        "Email" => $row['Email'],
                        "PaymentOption" => $row['PaymentOption'],
                        "Address" => $row['Address']
                    ));
                }

                return json_encode($returnarray);
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
    }

    //User Use. Customer gets list of Orders. Gets Email and Order Status as Parameter. Returns JSON list.
    //Returns Error value of 0 if empty, 1 if Error.
    function customerOrders($email, $orderstatus){
        $returnarray = array();
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM orders WHERE Status=? AND Email=?");
        $stmt->bind_param("ss", $orderstatus, $email);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                while($row = $result->fetch_assoc()){
                    array_push($returnarray, array(
                        "OrderID" => $row['OrderID'],
                        "Date" => $row['Date'],
                        "Time" => $row['Time'],
                        "Items" => $row['Items'],
                        "Quantity" => $row['Quantity'],
                        "Total" => $row['Total'],
                        "Status" => $row['Status'],
                        "Contact" => $row['Contact'],
                        "Email" => $row['Email'],
                        "PaymentOption" => $row['PaymentOption'],
                        "Address" => $row['Address']
                    ));
                }

                return json_encode($returnarray);
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
    }

    //IMPORTANT: SESSION_START FIRST BEFORE USING.
    //IMPORTANT: CALL getCurrentCart() BEFORE using addToCart()
    //User Use. Gets Cart from Database. Gets Email parameter. C kkreate $_SESSION['cart'] and $_SESSION['cartID']
    function getCurrentCart($username){
        $_SESSION['cart'] = array();
        $splitone = array();
        $splittwo = array();
        $counter = 0;
        $stmt = $GLOBALS['conn']->prepare("SELECT U_Cart FROM users WHERE U_Username= ?");
        $stmt->bind_param("s", $username);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows >= 1){
                while($row = $result->fetch_assoc()){
                    if($row['U_Cart'] != ""){
                        $splitone = explode('?',$row['U_Cart']);
                        foreach($splitone as $sone){
                            for($a = 0; $a < sizeof($splitone); $a++){
                                $splittwo = explode("@", $sone);
                            }
                            $_SESSION['cart'][$counter]= array($splittwo[0], $splittwo[1], $splittwo[2], $splittwo[3]);
                            $counter++;
                        }
                    }
                }
            }
            
        }
    }

    //IMPORTANT: SESSION_START FIRST BEFORE USING.
    //IMPORTANT: CALL getCurrentCart() BEFORE using addToCart()
    //User Use. Adds Item to Cart. Returns true if add successful, else false.
    function addToCart($username, $itemid, $price, $quantity, $size){
        $cartstring = "";
        $addtocartstring = "";
        $stmt = $GLOBALS['conn']->prepare("SELECT U_Cart FROM users WHERE U_Username= ?");
        $stmt->bind_param("s", $username);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $cartstring = $row['U_Cart'];
                }
            }
        }

        $addtocartstring = $itemid . "@" . $price . "@" . $quantity . "@" . $size . "@";
        $finalcart = $cartstring . "?" . $addtocartstring;

        $stmt = $GLOBALS['conn']->prepare("UPDATE users SET U_Cart=? WHERE U_Username=?");
        $stmt->bind_param("ss", $finalcart, $username);

        return $stmt->execute();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //IMPORTANT: SESSION_START FIRST BEFORE USING.
    //IMPORTANT: CALL getCurrentCart() BEFORE using addToCart()
    //User Use. Checks out Cart. Returns true if update successful, else false.
    function checkoutCart($username, $total, $contact, $email, $paymentoption, $address){
        $cartstring = "";
        $blank="";
        $stmt = $GLOBALS['conn']->prepare("SELECT U_Cart FROM users WHERE U_Username= ?");
        $stmt->bind_param("s", $username);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $cartstring = $row['U_Cart'];
                }
            }
        }
        date_default_timezone_set('Asia/Manila');
        $date = date("m/d/Y") . "";
        $time = date("h:i:s"). "";
        $status = "PENDING";
        $stmt = $GLOBALS['conn']->prepare("INSERT INTO orders(Date, Time, Items, Total, Status, Contact, Email, PaymentOption, Address) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sssisssss", $date, $time, $cartstring, $total, $status, $contact, $email, $paymentoption, $address);
        $stmt->execute();
        $stmt = $GLOBALS['conn']->prepare("UPDATE users SET U_Cart=? WHERE U_Username=?");
        $stmt->bind_param("ss", $blank, $username);

        $stmt->execute();
        //mail();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    function getUser($username){
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM users WHERE U_Username=?");
        $stmt->bind_param("s", $username);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                return json_encode($result->fetch_assoc());
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
        
        $stmt->close();
        $GLOBALS['conn']->close();
    }

?>