<?php

$servername = "localhost";
$username = "docgan";
$password = "healthyfoodie@ust";
$dbName = "healthyfoodie";
	

	$conn = new mysqli ($servername, $username, $password, $dbName);
	if(!$conn){
			die("Connection Failed. ".mysqli_connect_error);
	}


$id="12";
$name="isko";
$age="18";
$gender="male";
$grade="grade 3";

$sql = "INSERT INTO User (Id, Uname, Age, Gender, Grade) 
				VALUES ('".$id."','".$name."','".$age."','".$gender."','".$grade."')";
		$result2 = mysqli_query($conn ,$sql);

header('Location:dbpagephp');

?>