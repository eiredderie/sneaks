<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>HEALTHY FOODIE</title>
</head>
<style>

body {
	background-image:url("background2.jpg");
    background-size: 100%;
    background-repeat: repeat;
    font-family: Arial Narrow;
    background-color: brown;
    font-size: 20px;
 	
}
fieldset, h1 {
	background-color: white;
	border: 1px solid black;
	border-radius: 25px;
	color: #f2da94;
}
button{
	padding: 15px 30px;
	font-size: 20px;
	background-color: brown;
	background-color: #eeb063;
}
fieldset{
	background-color : #8c2a27;
}
#pas {
	color: #c74535;
	background-color: #eeb063;
}

</style>
<body>
	<center><img src="header.png" class="img-responsive" height="300" width="600" >

	<br><br>
	
	<form method="post">
	
	
	<center><fieldset> 
	
		<table>
			<center><legend><h1 id = "pas"><b>&nbsp LOGIN &nbsp <b/></h1></legend></center>
			<tr> <td><br><b><h2>Email:</h2></b></td>	<td><input type="text" name="emaildb" style="font-size:20pt;" required autofocus/></td> </tr>
			<tr> <td><b><h2>Password:</h2></b></td> 	<td><input type="password" name="dbpass" style="font-size:20pt;" required /></td> </tr>
		</table>	
		<p> <button type="submit" name="login" value="Submit"><b>Submit</b></button>

	</fieldset></center>
	</form>
</body>
</html>

<?php
	if(isset($_POST['login'])){
		$servername = "localhost";
		$username = "docgan";
		$password = "healthyfoodie@ust";
		$dbName = "healthyfoodie";
		
		
		$conn = new mysqli ($servername, $username, $password, $dbName);
		
		$email = $_POST["emaildb"];
		$pass = $_POST["dbpass"];
		//$encryptpass=md5.($pass);
		$stmt = $conn->prepare("SELECT AdminId FROM admin WHERE Email = ? AND Password = ?");
		$stmt->bind_param("ss",$email,$pass);
		$stmt->execute();
		$stmt->bind_result($results);
		$stmt->fetch();

		if(!$conn){
			echo "Error";
		}
		if($results==1){
			echo "login success";
			header('Location:dbpage.php');
		}
		else{
			echo $email." ".$pass;
		}
	}

?>