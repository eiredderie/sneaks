<?php
if(isset($_POST['buttons'])){
	if($_POST['buttons']=="Login"){
		header('Location:index.php');
	}
}
?>
<DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>HEALTHY FOODIE</title>
</head>
<style>

body {
	background-image:url("background2.jpg");
    background-size: 100%;
    background-repeat: repeat;
    font-family: Arial Narrow;
    background-color: brown;
    font-size: 20px;
 	
}
fieldset, h1 {
	background-color: white;
	border: 1px solid black;
	border-radius: 25px;
	color: #f2da94;
}
button{
	padding: 15px 30px;
	font-size: 20px;
	background-color: brown;
	background-color: #eeb063;
}
fieldset{
	background-color : #8c2a27;
}
#pas {
	color: #c74535;
	background-color: #eeb063;
}

</style>
	<center><img src="header.png" class="img-responsive" height="300" width="600" ></center>
<body>

	<br><br>
	
	<form action="registered.php" method="post">
	
	
	<center><fieldset> 
	
		<table>
			<center><legend><h1 id = "pas"><b>&nbsp REGISTER &nbsp <b/></h1></legend></center>
			<tr><th colspan='2'>Student Registered</th></tr>
			<tr>
				<td><button type="submit" name="buttons" value="Login"><b>Login</b></button></td>
			</tr>
		</table>	

	</fieldset></center>
	</form>
</body>
</html>
