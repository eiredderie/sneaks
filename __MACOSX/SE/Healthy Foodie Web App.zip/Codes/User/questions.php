<?php
session_start();
$_SESSION['q1']=array("Carbohydrates Belong to which food group?","Which food groups provides proteins?",
					"Vitamins are part of which food group?","Which food group provides energy for you to play?",
					"Which Food Group keeps your muscles strong?","Which Food Group gives many Minerals?",
					"Fruits and vegetables belong to which food group?","Which food provides energy for you to study?",
					"Which food group helps keep your bones healthy?","Which food group will help make your hair shiny?"
					);
$_SESSION['q2']="Identify the Food Group where this food belongs.";
$_SESSION['q3']="How often can you eat these foods?";	
$_SESSION['question1']=array(
					//IMAGES FOR #1-10 ako na bahala dito
					array("foods/spaghetti.png","foods/pork.png","foods/watermelon.png",
					"foods/cereal.png","foods/egg.png","foods/apple.png",
					"foods/coconut.png","foods/pandesal.png","foods/fish.png",
					"foods/eggplant.png"),
					array(1,2,3,1,2, 3,3,1,2,3) //1 = GO FOOD, 2= GROW FOOD, 3= GLOW FOOD //correct answer
					);
$_SESSION['question2']=array(
					//IMAGES FOR #11-40;
					array("foods/banana.png","foods/rice.png","foods/carrots.png","foods/Milk.png","foods/pork.png","foods/cereal.png","foods/bread.png","foods/cabbage.png","foods/chicken.png","foods/apple.png",
					"foods/watermelon.png","foods/noodles.png","foods/beef.png","foods/egg.png","foods/eggplant.png","foods/fish.png","foods/mango.png","foods/puto.png","foods/shrimp.png","foods/ampalaya.png",
					"foods/malungay.png","foods/coconut.png","foods/corn.png","foods/pineapple.png","foods/spaghetti.png","foods/pandesal.png","foods/cheese.png","foods/monggo.png","foods/sweet potato.png","foods/tomato.png"),
					//CORRECT ANSWER FOR #11-40
					array(3,1,3,2,2,1,1,3,2,3,
					      3,1,2,2,3,2,3,1,2,3,
					      3,3,1,3,1,1,2,2,1,2)
					);

					
//FOR TRAFFIC LIGHT FOODS;
$_SESSION['question3']=array(
					//IMAGES FOR #41-70;
					array("foods/icecream.png","foods/mango.png","foods/chips.png","foods/rice.png","foods/pancake.png","foods/donut.png","foods/coke.png","foods/cabbage.png","foods/burger.png","foods/hotdog.png",
					"foods/watermelon.png","foods/food_water.png","foods/bananaque.png","foods/pizza.png","foods/lolipop.png","foods/mashmallow.png","foods/tocino.png","foods/chicken nugget.png","foods/shrimp.png","foods/fishball.png",
					"foods/boiled banana.png","foods/coconut.png","foods/fried rice.png","foods/mayonnaise.png","foods/chicken breast.png","foods/cake.png","foods/lolipop.png","foods/fries.png","foods/kamoteque.png","foods/tomato.png"),
					//CORRECT ANSWER FOR #41-70
					array(3,1,3,1,2,3,3,1,2,2,
						  1,1,2,2,3,3,2,2,1,3,
					      1,1,2,2,1,3,3,1,2,1)
					);

?>