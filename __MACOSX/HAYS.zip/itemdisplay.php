<?php 
    SESSION_START();
    require_once('compiled.php');
    
    (($_SESSION['username'] == "") ||($_SESSION['fname'] == "") ||($_SESSION['lname'] == "")) ? header("Location: index.php") : null;
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>trial1_sneaks</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/4.1.0/cosmo/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-icons/3.0.1/iconfont/material-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aldrich">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+SC">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Anton">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arsenal">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body style="padding:0px;margin:-1px;">
    <div class="simple-slider">
        <div class="swiper-container">
            <div class="swiper-wrapper"></div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>
    </div>
    <div>
        <nav class="navbar navbar-light navbar-expand-md" style="background-color:#6f7a85;">
            <div class="container-fluid"><a class="navbar-brand text-monospace text-white" href="home.php" style="font-size:30px;color:white;font-family:sans-serif;"><img src="assets/img/SHOES-logo-mono.png" width="50" height="50"><strong>&nbsp;SNEAKS</strong></a><button class="navbar-toggler"
                data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="#"></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link text-capitalize text-white-50 active d-table-cell float-right" href="home.php" style="font-size:20px;font-family:sans-serif;margin-top:8px;color:#FBFCFC;"><i class="fa fa-tags"></i><strong>&nbsp;Products</strong></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link text-monospace text-white-50 d-table-cell float-right" href="cart.php" style="font-size:20px;font-family:sans-serif;margin-top:8px;"><i class="fa fa-shopping-cart"></i><strong>&nbsp;Cart</strong></a></li>
                    <li class="dropdown"><a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" style="margin:0px;font-size:25px;color:rgba(255,255,255,0.5);"><i class="icon ion-android-person" style="font-size:30px;color:rgba(255,255,255,0.5);"></i>&nbsp;<?php echo $_SESSION['fname'] . " " . $_SESSION['lname']?></a>
                        <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="account.php"><strong>Profile</strong></a><a class="dropdown-item" role="presentation" href="index.html"><strong>Log Out</strong></a></div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-md-6 align-items-center align-content-center align-self-center" style="width:514px;">
                <div class="align-items-center align-content-center align-self-center swiper-slide" style="background-image:url(https://placeholdit.imgix.net/~text?txtsize=68&amp;txt=Slideshow+Image&amp;w=1920&amp;h=500);width:500px;"><img class="img-thumbnail align-items-center align-content-center align-self-center" src="assets/img/1901_Merick-Derby.jpg" width="400px" height="400px" style="height:593px;width:514px;padding-top:20px;padding-bottom:0px;"></div>
            </div>
            <div class="col-md-6"><label style="font-size:40px;text-align:center;font-family:Arsenal, sans-serif;padding-top:30px;padding-left:0px;"><strong>CASUAL &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</strong></label>
                <label
                    style="font-size:30px;text-align:center;font-family:ABeeZee, sans-serif;padding-top:0px;padding-left:0px;"><strong>MERICK DERBY &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</strong></label><label style="font-size:30px;text-align:center;font-family:ABeeZee, sans-serif;padding-top:0px;padding-left:0px;"><strong>1901 Merick Derby</strong></label>
                    <hr><label style="font-size:30px;margin:0px;padding-right:0px;padding-left:0px;padding-top:2px;color:#424949;"><strong>PHP 3,750.00&nbsp;</strong></label><select style="height:40px;width:60px;padding-left:20px;margin:20px;"><option value="" selected="">Size</option><option value="">11</option><option value="">10.5</option><option value="">10</option><option value="">9.5</option><option value="">9</option><option value="">8.5</option><option value="">8</option><option value="">7.5</option><option value="">7</option></select>
                    <div
                        class="form-check" style="margin:0px;font-size:20px;"><input class="form-check-input" type="radio" id="formCheck-1"><label class="form-check-label" for="formCheck-1">Black</label></div>
            <div class="form-check"><input class="form-check-input" type="radio" id="formCheck-1"><label class="form-check-label" for="formCheck-1" style="font-size:20px;">White</label></div>
            <div class="form-check" style="padding-bottom:20px;"><input class="form-check-input" type="radio" id="formCheck-1"><label class="form-check-label" for="formCheck-1" style="font-size:20px;">Silver</label></div><input type="number" placeholder="No. of Order" style="height:33px;width:99px;">
            <label
                style="padding-right:20px;font-size:20px;padding-left:20px;"><strong>STOCKS LEFT: 10</strong></label><a class="btn btn-outline-primary active d-inline-flex align-items-center align-content-center align-self-center" role="button" href="cart.html" style="color:#FBFCFC;background-color:#424949;margin:0px;text-align:center;padding-top:0px;">ADD TO CART</a></div>
    </div>
    </div>
    </div>
    <div class="container">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr></tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
    <div></div>
    <div class="footer-clean" style="background-color:#424949;padding:32px;">
        <footer>
            <div class="container">
                <div class="row justify-content-center" style="background-color:rgba(251,252,252,0);">
                    <div class="col-sm-4 col-md-3 item" style="padding-right:0;">
                        <h3 style="color:#FBFCFC;">ABOUT US</h3>
                        <ul>
                            <li style="color:#FBFCFC;"><a href="#">Company</a></li>
                            <li style="color:#FBFCFC;">Shipping Information</li>
                            <li style="color:#FBFCFC;">Privacy Policy</li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3 style="color:#FBFCFC;">CONTACT US</h3>
                        <ul>
                            <li><a href="#" style="color:rgb(246,249,251);">España Blvd, Sampaloc, Manila</a></li>
                            <li style="color:#FBFCFC;"><a href="#">406 1611</a></li>
                            <li></li>
                        </ul><a href="#" style="color:#FBFCFC;">sneaks.ph@gmail.com</a></div>
                    <div class="col-lg-3 item social"><a href="#" style="background-color:#424949;"><i class="icon ion-social-facebook" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-twitter" style="color:#FBFCFC;background-color:#424949;"></i></a>
                        <a
                            href="#" style="background-color:#424949;"><i class="icon ion-social-snapchat" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-instagram" style="color:#FBFCFC;"></i></a>
                            <p class="copyright"
                                style="color:#FBFCFC;font-size:21px;">Sneaks © 2018</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>