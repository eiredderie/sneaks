﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;



public class SettingsMenu : MonoBehaviour {

    public AudioMixer audioMixer;

	public void SetVolume(float volume)
    {
        audioMixer.SetFloat("volume",volume);
        /*
         SpeechSynthesizer synthesizer = new SpeechSynthesizer();
            synthesizer.Volume = 100;  // 0...100
            synthesizer.Rate = -2;     // -10...10

            // Synchronous
            synthesizer.Speak("Hello World");

            // Asynchronous
            synthesizer.SpeakAsync("Hello World"); 
         */
    }
}
