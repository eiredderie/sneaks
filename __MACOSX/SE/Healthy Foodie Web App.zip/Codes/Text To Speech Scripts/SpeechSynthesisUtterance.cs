﻿namespace UnityWebGLSpeechSynthesis
{
    public class SpeechSynthesisUtterance
    {
        public int _mReference = 0;
    }
}
