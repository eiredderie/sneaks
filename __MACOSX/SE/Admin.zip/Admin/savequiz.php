<?php
session_start();
if(isset($_SESSION['access'])){
	

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		
	
	$conn = new mysqli ($servername, $username, $password, $dbName);
	$_SESSION['saveMsg']="Settings Saved";
	$pre=$_POST['pretest'];
	$post=$_POST['posttest'];
	$stmt = $conn->prepare("Update settings Set PretestStat = ? , PosttestStat = ? WHERE Id = 1");
	$stmt->bind_param("ss",$pre,$post);
	$stmt->execute();
	
	header("Location:quiz.php");

}
?>