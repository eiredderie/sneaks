<?php


	$host = "localhost";
	$user = "id5591164_docgan";
	$pass = "docgan@2018";
	$db = "id5591164_healthyfoodie";
		
$table = 'user';
$tablepr1 = "pretestq1";
$tablepr2 = "pretestq2";
$tablepr3 = "pretestq3";
$tablept1 = "posttestq1";
$tablept2 = "posttestq2";
$tablept3 = "posttestq3";
$file = 'StudentScores';

$link = mysqli_connect($host, $user, $pass) or die("Can not connect." . mysql_error());
mysqli_select_db($link,$db) or die("Can not connect.");
$csv_output ="";

$columns=array();


$result = mysqli_query($link,"SHOW COLUMNS FROM ".$table);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
       $columns[]= $row['Field'];
    }
}
$result = mysqli_query($link,"SHOW COLUMNS FROM ".$tablepr1);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
       $columns[]= $row['Field'];
    }
}
$result = mysqli_query($link,"SHOW COLUMNS FROM ".$tablepr2);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
       $columns[]= $row['Field'];
    }
}
$result = mysqli_query($link,"SHOW COLUMNS FROM ".$tablepr3);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
       $columns[]= $row['Field'];
    }
}

$result = mysqli_query($link,"SHOW COLUMNS FROM ".$tablept1);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
       $columns[]= $row['Field'];
    }
}
$result = mysqli_query($link,"SHOW COLUMNS FROM ".$tablept2);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
       $columns[]= $row['Field'];
    }
}
$result = mysqli_query($link,"SHOW COLUMNS FROM ".$tablept3);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
       $columns[]= $row['Field'];
    }
}


$values = mysqli_query($link,"SELECT * FROM user AS m LEFT JOIN pretestq1 AS pr1 ON m.id = pr1.pretestq1id 
LEFT JOIN pretestq2 AS pr2 ON m.id = pr2.pretestq2id
LEFT JOIN pretestq3 AS pr3 ON m.id = pr3.pretestq3id
LEFT JOIN posttestq1 AS pt1 ON m.id = pt1.posttestq1id
LEFT JOIN posttestq2 AS pt2 ON m.id = pt2.posttestq2id
LEFT JOIN posttestq3 AS pt3 ON m.id = pt3.posttestq3id");
foreach($columns as $name)
	$csv_output .= $name.", ";
	
$csv_output.="
";
while ($rowr = mysqli_fetch_row($values)) {
	foreach($rowr as $data)
	$csv_output .= $data.", ";
	
	
	$csv_output.="
";
}
$csv_output.="
";


$filename = $file."_".date("Y-m-d_H-i",time());
header("Content-type: application/vnd.ms-excel");
header("Content-disposition: csv" . date("Y-m-d") . ".csv");
header("Content-disposition: filename=".$filename.".csv");
print $csv_output;
exit

?>