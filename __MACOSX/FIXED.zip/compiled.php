<?php 
	
	$servername = 'localhost';
	$user = 'root';
	$pass = '';
	$db = 'sneaks';

	$conn = new mysqli($servername, $user, $pass, $db) or die("Unable to connect");

	function login($email, $password){
		
        $stmt = $GLOBALS['conn']->prepare("SELECT UserID, U_Username, U_FirstName, U_MiddleName, U_LastName FROM Users WHERE U_Email = ? AND U_Password = ?");
        $encryptpass=md5($password);
        $stmt->bind_param("ss",$email, $encryptpass);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
                $_SESSION['loginErr']="Incorrect Username and Password".$email." ".$password;
                return false;
            
            }
            else{
                while($row = $result->fetch_assoc()){
                    $_SESSION['id'] = $row['UserID'];
                    $_SESSION['username'] = $row['U_Username'];
                    $_SESSION['fname'] = $row['U_FirstName'];
                    $_SESSION['mname'] = $row['U_MiddleName'];
                    $_SESSION['lname'] = $row['U_LastName'];
                    
                    $_SESSION['loginErr']="Login Successfully";
		
                }

                return true;
            }
        }
        else{
            return false;
        }
}


	function signup($uname, $fname, $lname, $mname, $email, $pass, $contact, $address){

		$stmt = $GLOBALS['conn']->prepare("SELECT UserID FROM Users WHERE U_Email = ? OR U_Username = ?");
		$stmt->bind_param("ss",$email,$uname);
		$stmt->execute();
		$stmt->bind_result($result);
		$stmt->fetch();

		if($result>=1){
            $_SESSION['signupErr']="Username/Email already used in another account.";
            return false;
		}
		else{
			$stmt = $GLOBALS['conn']->prepare("INSERT INTO Users (U_FirstName, U_MiddleName, U_LastName, U_Username, U_Password, U_Email, U_Contact, U_AccountType, U_Address) 
				VALUES (?,?,?,?,?,?,?,?,?)");
            $type="USER";
            $encrpytpass = md5($pass);
			$stmt->bind_param("sssssssss", $fname, $mname, $lname, $uname, $encrpytpass, $email, $contact, $type, $address);
			$stmt->execute();

			//CONFIRMATION FOR EMAIL TO BE ADDED

			$_SESSION['signupErr']="Sign Up Successful.";
            return true;
		}
	}


	//SORT

	function displaySort($column, $order){


		$stmt = "SELECT * FROM items ORDER BY ".$column." ".$order; 
		$result = @mysqli_query($GLOBALS['conn'] ,$stmt);

		while($row = mysqli_fetch_array($result)) {
			$ids[] = $row['ItemID'];
			$brands[] = $row['I_Brand'];
			$types[] = $row['I_Type'];
			$names[] = $row['I_Name'];
			$prices[] = $row['I_Price'];
			$stocks[] = $row['I_Stock'];
			$images[] = $row['I_Image'];
		}
		return array($ids, $brands, $types, $names, $prices, $stocks, $images);
	}

	//IDDISPLAY
	function displayItem($id){

		$stmt = $GLOBALS['conn']->prepare("SELECT * FROM items WHERE ItemID = ?"); 
		$stmt->bind_param("i",$id);
		$stmt->execute();
		$stmt->bind_result($ids, $brands, $types, $names, $prices, $stocks, $images);
		$stmt->fetch();

		return array($ids, $brands, $types, $names, $prices, $stocks, $images);
	}

	 function navigate($filename){
        header('Location: $filename');
    }

    //IMPORTANT: Create products folder for image store.
    //IMPORTANT: Change default Image Name.
    //Admin Use. Adds Item to Database. Returns true if upload successful, else false.
    function addItem($brand, $type, $name, $price, $stock, $imagename, $imagetmploc){
        if($imagename != NULL){
        	$seperate = explode(".", $imagename);
        	$filetype = end($seperate);
            $imagenamefinal = "Product." . $filetype;
           	$location = "products/" . $imagenamefinal;
        	move_uploaded_file($imagetmploc, $location);
        }

        $stmt = $GLOBALS['conn']->prepare("INSERT INTO items(I_Brand, I_Type, I_Name, I_Price, I_Stock, I_Image) 
            VALUES(?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssii", $brand, $type, $name, $price, $stock, $location);

        return $stmt->execute();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin Use. Edit Item in Database. Returns true if update successful, else false.
    function editItem($itemid, $brand, $type, $name, $price){
        $stmt = $GLOBALS['conn']->prepare("UPDATE items SET I_Brand=?, I_Type=?, I_Name=?, I_Price=? WHERE ItemID=?");
        $stmt->bind_param("sssii", $brand, $type, $name, $price, $itemid);
        
        return $stmt->execute();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin Use. Delete Item in Database. Takes ItemID as parameter. 
    //Returns true if update successful, else false.
    function deleteItem($itemid){
        $stmt = $GLOBALS['conn']->prepare("DELETE FROM items WHERE ItemID=?");
        $stmt->bind_param("i", $itemid);  


        return $stmt->execute();
        $stmt->close();
        $GLOBALS['conn']->close();
    }
    //Admin and User Use. Gets details of Item. Takes ItemID as parameter. Returns JSON value for Item Details. 
    //Returns Error value of 0 if empty, 1 if Error.
    function getItem($itemid){
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM items WHERE ItemID=?");
        $stmt->bind_param("i", $itemid);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                return json_encode($result->fetch_assoc());
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
        
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin and User Use. Searches for Items depending on keyword parameter. Returns JSON Items.
    //Returns Error value of 0 if empty, 1 if Error.
    function searchItem($keyword){
        $returnarray = array();
        $likekeyword = '%' . htmlspecialchars($keyword) . '%';
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM items WHERE (I_Brand || I_Type || I_Name) LIKE ?");
        $stmt->bind_param("s", $likekeyword);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                while($row = $result->fetch_assoc()){
                    array_push($returnarray, array(
                        "Brand" => $row['I_Brand'],
                        "Type" => $row['I_Type'],
                        "Name" => $row['I_Brand'],
                        "Price" => $row['I_Price'],
                        "Image" => $row['I_Image']
                    ));
                }

                return json_encode($returnarray);
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
    }

    //Admin Use. Confirms order. Returns true if update successful, else false. Emails Customer for Updates.
    function confirmOrder($orderid){
        $stmt = $GLOBALS['conn']->prepare("UPDATE orders SET Status=? WHERE OrderID=?");
        $stmt->bind_param("si", "CONFIRMED", '$orderid');


        return $stmt->execute();
        //email User
        //mail();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin Use. Declines order. Returns true if update successful, else false. Emails Customer for Updates.
    function declineOrder($orderid){
        $stmt = $GLOBALS['conn']->prepare("UPDATE orders SET Status=? WHERE OrderID=?");
        $stmt->bind_param("si", "DECLINED", '$orderid');


        return $stmt->execute();
        //email User
        //mail();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //User Use. Cancels order. Returns true if update successful, else false. Emails Admin for Updates.
    function cancelOrder($orderid){
        $stmt = $GLOBALS['conn']->prepare("UPDATE orders SET Status=? WHERE OrderID=?");
        $stmt->bind_param("si", "CANCELLED", '$orderid');

        return $stmt->execute();
        //email Admin
        //mail();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin Use. Add Stocks in Database. Gets number and ItemID as parameter. 
    //Returns true if update successful, else false.
    function addStocks($incrementNumber, $itemid){
        //$stmt = $GLOBALS['conn']->prepare("UPDATE items SET I_Stock = ? WHERE ItemID=?");
        $stmt = $GLOBALS['conn']->prepare("UPDATE items SET I_Stock += ? WHERE ItemID=?");
        $stmt->bind_param("ii", $incrementNumber, $itemid);

        return $stmt->execute();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin and User Use. Gets Order Details. Returns JSON value. 
    //Returns Error value of 0 if empty, 1 if Error.
    function getOrder($orderid){
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM orders WHERE OrderID=?");
        $stmt->bind_param("i", $orderid);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                return json_encode($result->fetch_assoc());
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
        
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //Admin Use. Gets Confirmed and Pending Orders. Returns JSON list.
    //Returns Error value of 0 if empty, 1 if Error.
    function adminOrders(){
        $returnarray = array();
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM orders WHERE (Status = 'CONFIRMED') || (Status = 'PENDING') ORDER BY Status");

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                while($row = $result->fetch_assoc()){
                    array_push($returnarray, array(
                        "OrderID" => $row['OrderID'],
                        "Date" => $row['Date'],
                        "Time" => $row['Time'],
                        "Items" => $row['Items'],
                        "Quantity" => $row['Quantity'],
                        "Total" => $row['Total'],
                        "Status" => $row['Status'],
                        "Contact" => $row['Contact'],
                        "Email" => $row['Email'],
                        "PaymentOption" => $row['PaymentOption'],
                        "Address" => $row['Address']
                    ));
                }

                return json_encode($returnarray);
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
    }

    //User Use. Customer gets list of Orders. Gets Email and Order Status as Parameter. Returns JSON list.
    //Returns Error value of 0 if empty, 1 if Error.
    function customerOrders($email, $orderstatus){
        $returnarray = array();
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM orders WHERE Status=? AND Email=?");
        $stmt->bind_param("ss", $orderstatus, $email);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                while($row = $result->fetch_assoc()){
                    array_push($returnarray, array(
                        "OrderID" => $row['OrderID'],
                        "Date" => $row['Date'],
                        "Time" => $row['Time'],
                        "Items" => $row['Items'],
                        "Quantity" => $row['Quantity'],
                        "Total" => $row['Total'],
                        "Status" => $row['Status'],
                        "Contact" => $row['Contact'],
                        "Email" => $row['Email'],
                        "PaymentOption" => $row['PaymentOption'],
                        "Address" => $row['Address']
                    ));
                }

                return json_encode($returnarray);
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
    }

    //IMPORTANT: SESSION_START FIRST BEFORE USING.
    //IMPORTANT: CALL getCurrentCart() BEFORE using addToCart()
    //User Use. Gets Cart from Database. Gets Email parameter. Create $_SESSION['cart'] and $_SESSION['cartID']
    function getCurrentCart($email){
        $jsonoutput = "";
        $cartid = null;
        $_SESSION['cart'] = array();
        $_SESSION['cartID'] = "";
        $stat="CART";
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM orders WHERE Status= ? AND Email= ? ");
        $stmt->bind_param("ss", $stat, $email);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
            	$jsonoutput = "";
            	$cartid = "";
            }else if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $jsonoutput = $row['Items'];
                    $cartid = $row['OrderID'];
                }
            }
        }

        $_SESSION['cart'] = json_decode($jsonoutput, true);
        $_SESSION['cartID'] = $cartid;
    }

    //IMPORTANT: SESSION_START FIRST BEFORE USING.
    //IMPORTANT: CALL getCurrentCart() BEFORE using addToCart()
    //User Use. Adds Item to Cart. Returns true if add successful, else false.
    function addToCart($orderid, $itemid, $price, $quantity){
        array_push($_SESSION['cart'], array(
            "ItemID" => $itemid,
            "Price" => $price,
            "Quantity" => $quantity
        ));

        $newItems = json_encode($_SESSION['cart']);
        
        $stmt = $GLOBALS['conn']->prepare("UPDATE orders SET Items=? WHERE OrderID=?");
        $stmt->bind_param("si", $newItems, $orderid);

      

        return $stmt->execute();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    //IMPORTANT: SESSION_START FIRST BEFORE USING.
    //IMPORTANT: CALL getCurrentCart() BEFORE using addToCart()
    //User Use. Checks out Cart. Returns true if update successful, else false.
    function checkoutCart($orderid){
        $stmt = $GLOBALS['conn']->prepare("UPDATE orders SET Status=? WHERE OrderID=?");
        $stmt->bind_param("si", "PENDING", $orderid);

        if($stmt->execute()){
            return true;
            $_SESSION['cart'] = array();
        }
        else{
            return false;
        }

        //return $stmt->execute();
        //mail();
        $stmt->close();
        $GLOBALS['conn']->close();
    }

    function getUser($username){
        $stmt = $GLOBALS['conn']->prepare("SELECT * FROM users WHERE U_Username=?");
        $stmt->bind_param("s", $username);

        if($stmt->execute()){
            $result = $stmt->get_result();
            if($result->num_rows === 0){
                return json_encode(array('Error'=>0));
            }
            else{
                return json_encode($result->fetch_assoc());
            }
        }
        else{
            return json_encode(array('Error'=>1));
        }
        
        $stmt->close();
        $GLOBALS['conn']->close();
    }

?>