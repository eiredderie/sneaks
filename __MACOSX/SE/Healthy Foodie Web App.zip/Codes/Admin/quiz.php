<?php
session_start();
if(isset($_SESSION['access'])){
	

	$servername = "localhost";
	$username = "id5591164_docgan";
	$password = "docgan@2018";
	$dbName = "id5591164_healthyfoodie";
		
	
	$conn = new mysqli ($servername, $username, $password, $dbName);

	$sql = "SELECT PretestStat, PosttestStat FROM settings where ID=1"; //You don't need a ; like you do in SQL
	$result = mysqli_query($conn ,$sql);	
	
	
if(isset($_POST['buttons'])){
	if($_POST['buttons']=="Go Back"){
		header('Location:dbpage.php');
	}
	else if($_POST['buttons']=="Save"){
		header('Location:savequiz.php');
	}
	else{
		header('Location:logout.php');
	}
}
	
	echo "
		<!DOCTYPE html>
		<html>
		<head>
		<meta charset='ISO-8859-1'>
		<title>HEALTHY FOODIE</title>
		</head>
		<style>

		body {
			background-image:url('background2.jpg');
		    background-size: 100%;
		    background-repeat: repeat;
		    font-family: Arial Narrow;
		    background-color: brown;
		    font-size: 20px;
		 	
		}
		fieldset, h1 {
			background-color: white;
			border: 1px solid black;
			border-radius: 25px;
			color: #f2da94;
		}
		button{
			padding: 15px 30px;
			font-size: 20px;
			background-color: brown;
			background-color: #eeb063;
		}
		fieldset{
			background-color : #8c2a27;
		}
		#pas {
			color: #c74535;
			background-color: #eeb063;
		}
		#out{
			font-size: 15px;
			padding: 10px 20px;
		}
		#stud{
			font-size: 15px;
			padding: 5px 10px;
		}
		table{
            background-color: #03cea4;
            border-radius: 9px;
            color: black;  
            border: 3px solid gray;
            width:45%;
        }

        td,tr,th{
            text-align: center;
            font-size: 20px;
            border:none;
        }
		</style>
		<body>
			<center><img src='header.png' class='img-responsive' height='300' width='600' >

			<br><br>
			
			<form action='' method='POST'>
			
			
			
			<center><fieldset> 
			
				<table>
					<center><legend><h1 id = 'pas'><b>&nbsp QUIZ SETTINGS &nbsp <b/></h1></legend></center>";
					echo "<h3>";
					if(isset($_SESSION['saveMsg'])) echo $_SESSION['saveMsg'];
					echo "</h3>";
					$names=mysqli_fetch_assoc($result);
					if($names!=NULL){
						$result = mysqli_query($conn ,$sql);
							while($row= mysqli_fetch_row($result))
							{
								echo "<tr>";
								
									if($row[0]=="YES")
										echo "<tr><th><p>Randomize Pretest Questions?</th><td><select name='pretest'><option value='YES' selected>YES</option><option value='NO'>NO</option></select></td></tr>";
									else 
										echo "<tr><th><p>Randomize Pretest Questions?</th><td><select name='pretest'><option value='YES'>YES</option><option value='NO' selected>NO</option></select></td></tr>";
									if($row[1]=="YES")
										echo "<tr><th><p>Randomize Posttest Questions?</th><td><select name='posttest'><option value='YES' selected>YES</option><option value='NO'>NO</option></select></td></tr>";
									else 
										echo "<tr><th><p>Randomize Posttest Questions?</th><td><select name='posttest'><option value='YES'>YES</option><option value='NO' selected>NO</option></select></td></tr>";
								
								echo "</tr>";
								$row--;
							}   
					}
					else{
						echo "NO DATA";
					}
					echo "
				</table>	
				<br><br>
				<p> <button id='out' type=submit name=buttons value='Save' formaction='savequiz.php'><b>Save</b></button> <button id='out' type=submit name=buttons value='Go Back'><b>Go Back</b></button>

			</fieldset></center>
			</form>
		</body>
		</html>

		</form>
		</body>
	";
}
else{
	header('Location:login.php');
}


?>

