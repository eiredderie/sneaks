﻿using System;
using System.Collections;
#if UNITY_WEBGL && !UNITY_EDITOR
using System.Runtime.InteropServices;
#endif
using UnityEngine;

namespace UnityWebGLSpeechSynthesis
{
    public class WebGLSpeechSynthesisPlugin : BaseSpeechSynthesisPlugin, ISpeechSynthesisPlugin
    {
        /// <summary>
        /// Singleton instance
        /// </summary>
        private static WebGLSpeechSynthesisPlugin _sInstance = null;

        /// <summary>
        /// Get singleton instance
        /// </summary>
        public static WebGLSpeechSynthesisPlugin GetInstance()
        {
            return _sInstance;
        }

#if UNITY_WEBGL && !UNITY_EDITOR
        private class OnlyWebGL
        {
            [DllImport("__Internal")]
            public static extern bool IsAvailable();

            [DllImport("__Internal")]
            public static extern void Init();

            [DllImport("__Internal")]
            public static extern string GetVoices();

            [DllImport("__Internal")]
            public static extern int CreateSpeechSynthesisUtterance();

            [DllImport("__Internal")]
            public static extern void SetUtterancePitch(int reference, string pitch);

            [DllImport("__Internal")]
            public static extern void SetUtteranceRate(int reference, string rate);

            [DllImport("__Internal")]
            public static extern void SetUtteranceText(int reference, string text);

            [DllImport("__Internal")]
            public static extern void SetUtteranceVoice(int reference, string voiceURI);

            [DllImport("__Internal")]
            public static extern void Speak(int reference);

            [DllImport("__Internal")]
            public static extern bool HasOnEnd();

            [DllImport("__Internal")]
            public static extern string GetOnEnd();

            [DllImport("__Internal")]
            public static extern void Cancel();
        }
#endif

        /// <summary>
        /// Set the singleton instance
        /// </summary>
        private void Awake()
        {
            _sInstance = this;
        }

        /// <summary>
        /// Get the proxy on end events and then fire callback
        /// </summary>
        /// <returns></returns>
        IEnumerator ProxyOnEnd()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            //Debug.Log("ProxyOnEnd:");
            while (true)
            {
                if (OnlyWebGL.HasOnEnd())
                {
                    string jsonData = OnlyWebGL.GetOnEnd();
                    if (string.IsNullOrEmpty(jsonData))
                    {
                        yield return new WaitForSeconds(1f);
                        continue;
                    }

                    //Debug.Log("ProxyOnEnd: "+jsonData);
                    SpeechSynthesisEvent speechSynthesisEvent =
                        JsonUtility.FromJson<SpeechSynthesisEvent>(jsonData);
                    if (null != speechSynthesisEvent)
                    {
                        //Debug.LogFormat("ProxyOnEnd: listener count={0}", _sOnSynthesisOnEnd.Count);
                        for (int i = 0; i < _sOnSynthesisOnEnd.Count; ++i)
                        {
                            DelegateHandleSynthesisOnEnd listener = _sOnSynthesisOnEnd[i];
                            if (null != listener)
                            {
                                listener.Invoke(speechSynthesisEvent);
                            }
                        }
                    }
                }
                yield return new WaitForFixedUpdate();
            }
#else
            yield break;
#endif
        }

        public bool IsAvailable()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            return OnlyWebGL.IsAvailable();
#else
            return false;
#endif
        }

        public void CreateSpeechSynthesisUtterance(Action<SpeechSynthesisUtterance> callback)
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            int index = OnlyWebGL.CreateSpeechSynthesisUtterance();
            if (index < 0)
            {
                callback.Invoke(null);
                return;
            }
            SpeechSynthesisUtterance instance = new SpeechSynthesisUtterance();
            instance._mReference = index;
            callback.Invoke(instance);
            return;
#else
            callback.Invoke(null);
            return;
#endif
        }

        public void Speak(SpeechSynthesisUtterance speechSynthesisUtterance)
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            OnlyWebGL.Speak(speechSynthesisUtterance._mReference);
#endif
        }

        public void Cancel()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            OnlyWebGL.Cancel();
#endif
        }

#if UNITY_WEBGL && !UNITY_EDITOR
        void Start()
        {
            if (OnlyWebGL.IsAvailable())
            {
                OnlyWebGL.Init();
                StartCoroutine(ProxyOnEnd());
            }
        }
#endif

        public void GetVoices(Action<VoiceResult> callback)
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            string jsonData = OnlyWebGL.GetVoices();
            if (jsonData == "")
            {
                callback.Invoke(null);
                return;
            }
            //Debug.Log("GetVoices: "+jsonData);
            VoiceResult result = JsonUtility.FromJson<VoiceResult>(jsonData);
            if (null != result &&
                null != result.voices)
            {
                for (int i = 0; i < result.voices.Length; ++i)
                {
                    Voice voice = result.voices[i];
                    if (null == voice)
                    {
                        continue;
                    }
                    if (null == voice.lang)
                    {
                        continue;
                    }
                    string display = null;
                    switch (voice.lang)
                    {
                        case "de-DE":
                            display = "German (Germany)";
                            break;
                        case "es-ES":
                            display = "Spanish (Spain)";
                            break;
                        case "es-US":
                            display = "Spanish (United States)";
                            break;
                        case "fr-FR":
                            display = "French (France)";
                            break;
                        case "hi-IN":
                            display = "Hindi (India)";
                            break;
                        case "id-ID":
                            display = "Indonesian (Indonesia)";
                            break;
                        case "it-IT":
                            display = "Italian (Italy)";
                            break;
                        case "ja-JP":
                            display = "Japanese (Japan)";
                            break;
                        case "ko-KR":
                            display = "Korean (South Korea)";
                            break;
                        case "nl-NL":
                            display = "Dutch (Netherlands)";
                            break;
                        case "pl-PL":
                            display = "Polish (Poland)";
                            break;
                        case "pt-BR":
                            display = "Portuguese (Brazil)";
                            break;
                        case "ru-RU":
                            display = "Russian (Russia)";
                            break;
                        case "zh-CN":
                            display = "Mandarin (China)";
                            break;
                        case "zh-HK":
                            display = "Cantonese (China)";
                            break;
                        case "zh-TW":
                            display = "Mandarin (Taiwan)";
                            break;
                    }
                    if (null != display)
                    {
                        voice.display = display;
                    }
                }
            }
            callback.Invoke(result);
            return;
#else
            callback.Invoke(null);
#endif
        }

        public void SetPitch(SpeechSynthesisUtterance utterance, float pitch)
        {
            if (null == utterance)
            {
                Debug.LogError("Utterance not set!");
                return;
            }
#if UNITY_WEBGL && !UNITY_EDITOR
            OnlyWebGL.SetUtterancePitch(utterance._mReference, pitch.ToString());
#endif
        }
        public void SetRate(SpeechSynthesisUtterance utterance, float rate)
        {
            if (null == utterance)
            {
                Debug.LogError("Utterance not set!");
                return;
            }
#if UNITY_WEBGL && !UNITY_EDITOR
            OnlyWebGL.SetUtteranceRate(utterance._mReference, rate.ToString());
#endif
        }
        public void SetText(SpeechSynthesisUtterance utterance, string text)
        {
            if (null == utterance)
            {
                Debug.LogError("Utterance not set!");
                return;
            }
#if UNITY_WEBGL && !UNITY_EDITOR
            OnlyWebGL.SetUtteranceText(utterance._mReference, text);
#endif
        }
        public void SetVoice(SpeechSynthesisUtterance utterance, Voice voice)
        {
            if (null == utterance)
            {
                Debug.LogError("Utterance not set!");
                return;
            }
            if (null == voice)
            {
                Debug.LogError("Voice not set!");
                return;
            }
#if UNITY_WEBGL && !UNITY_EDITOR
            OnlyWebGL.SetUtteranceVoice(utterance._mReference, voice.voiceURI);
#endif
        }

        public void ManagementCloseBrowserTab()
        {
            //not used
        }

        public void ManagementCloseProxy()
        {
            //not used
        }

        public void ManagementLaunchProxy()
        {
            //not used
        }

        public void ManagementOpenBrowserTab()
        {
            //not used
        }

        public void ManagementSetProxyPort(int port)
        {
            //not used
        }
    }
}
