<?php 
    SESSION_START();
    require_once('compiled.php');

    (isset($_SESSION['username']) && isset($_SESSION['fname']) && isset($_SESSION['lname'])) ? header("Location: home.php") : null;

    if(!isset($_SESSION['loginErr'])){
        $_SESSION['loginErr'] = "";
    }
    if(isset($_POST['submit'])){
        if(login($_POST['email'], $_POST['password'])){
            header("Location: home.php");
        }
        else{
            header("Location: index.php");
        }
    }
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>trial1_sneaks</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/4.1.0/cosmo/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-icons/3.0.1/iconfont/material-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aldrich">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+SC">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Anton">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arsenal">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body>
    <nav class="navbar navbar-light navbar-expand-md" style="background-color:#6f7a85;">
        <div class="container-fluid"><a class="navbar-brand" href="index.html" style="font-size:25px;font-family:'Source Sans Pro', sans-serif;color:white;"><strong>&nbsp;</strong><img src="assets/img/SHOES-logo-mono.png" width="50" height="50"><strong>&nbsp;SNEAKS</strong></a><button class="navbar-toggler"
                data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav"></ul>
            </div>
        </div>
    </nav>
    <div class="login-clean">
        <form method="post" style="background-color:#424949  ;">
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><i class="icon ion-social-html5-outline" style="color:white;"></i></div>
            <div class="form-group"><center><h4><?=$_SESSION['loginErr'] ?></h4></center></div>
            <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email" required></div>
            <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password" required></div>
            <div class="form-group"><button class="btn btn-primary btn-block" role="button" name="submit" type="submit" style="background-color:#FBFCFC;color:#424949;"><strong>LOG IN</strong></button></div>
            <a href="signup.php" class="forgot"><span style="text-decoration: underline;">Don't yet have an account? Sign Up here.</span></a>
            <a class="forgot"><span style="text-decoration: underline;">Forgot your email or password?</span></a>
        </form>
    </div>
    <div class="footer-clean" style="background-color:#424949;padding:32px;">
        <footer>
            <div class="container">
                <div class="row justify-content-center" style="background-color:rgba(251,252,252,0);">
                    <div class="col-sm-4 col-md-3 item" style="padding-right:0;">
                        <h3 style="color:#FBFCFC;">ABOUT US</h3>
                        <ul>
                            <li style="color:#FBFCFC;"><a href="#">Company</a></li>
                            <li style="color:#FBFCFC;">Shipping Information</li>
                            <li style="color:#FBFCFC;">Privacy Policy</li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3 style="color:#FBFCFC;">CONTACT US</h3>
                        <ul>
                            <li><a href="#" style="color:rgb(246,249,251);">España Blvd, Sampaloc, Manila</a></li>
                            <li style="color:#FBFCFC;"><a href="#">406 1611</a></li>
                            <li></li>
                        </ul><a href="#" style="color:#FBFCFC;">sneaks.ph@gmail.com</a></div>
                    <div class="col-lg-3 item social"><a href="#" style="background-color:#424949;"><i class="icon ion-social-facebook" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-twitter" style="color:#FBFCFC;background-color:#424949;"></i></a>
                        <a
                            href="#" style="background-color:#424949;"><i class="icon ion-social-snapchat" style="background-color:#424949;color:#FBFCFC;"></i></a><a href="#" style="background-color:#424949;"><i class="icon ion-social-instagram" style="color:#FBFCFC;"></i></a>
                            <p class="copyright"
                                style="color:#FBFCFC;font-size:21px;">Sneaks © 2018</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>