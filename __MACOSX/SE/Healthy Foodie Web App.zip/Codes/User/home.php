<!DOCTYPE html>
<html>
    <head>
        
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      
        <title>Healthy Foodie</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="style2.css">
	<script src="js/jquery.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<script src="js/imgzoom.min.js"></script>
	<script src="js/scrollreveal.min.js"></script>
	<script src="js/countdown.min.js"></script>
        <link rel="stylesheet" href="footer.css">
        <style>
		h1{
                font-family: montserrat;
                color: #080808;
                text-shadow: 0 0 3px #FF0000, 0 0 5px #0000FF;
            }
        .dropbtn {
			background-color: #4CAF50;
			color: white;
			padding: 16px;
			font-size: 16px;
			border: none;
		}

		.dropdown {
			position: relative;
			display: inline-block;
		}

		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f1f1f1;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			z-index: 1;
		}

		.dropdown-content a {
			color: black;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
		}

		.dropdown-content a:hover {background-color: #ddd}

		.dropdown:hover .dropdown-content {
			display: block;
		}

		.dropdown:hover .dropbtn {
			background-color: #3e8e41;
		}
      </style>
    </head>
    
    
    
    <body>
        
        <div id="nav">
	  <a class="navbar-brand navbar-link" href="index.php"><img src="logo_HF.png" id="logo"></a>
        <div class="container">
            <div class="pull-left">
                <div id="logo">

                </div>
            </div>
            <div class="pull-right">
                <ul id="navigation">
                    <li class="active"><a href="home.php">HOME</a></li>
                    <li><a href="test.php">TESTS</a></li>
                    <li><a href="aboutus.php">ABOUT US</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                    <li><a href="logout.php">LOGOUT</a></li>
                    </div>
                    </ul>
            </div>
            <div class="clear"></div>
        </div>
    </div>

    <br>
	<!--<div id="slider">
		<div class="imgheader" style="background-image: url(slidernew_HF.png);"></div>
	</div>-->
	<br></br>
    <div class="container">
        <div class="row" align="center">
                <div class="col-md-12">
                    <h1 class="text-center">HEALTHY FOODIE <br>NUTRITION APPLICATION</h1>
                </div>
            </div>
        </div>
		
	<div>
	    <form method="post">
	    <div class="col-md-4"></div>
	    <div class="col-md-4">
				<div class="well well-lg">
					<center><h1><b></b></h1></center>
					<center><image src="menu.jpg" class="img-responsive" height="200" width="200" alt="TEST">
					</center><br>
					<center><button type="submit" value="true" name="post" formaction="test.php" class="btn btn-primary">Take the Tests</button></center>
				</div>	
		</div>
		
	    <div class="col-md-4"></div>
	    </form>
    </div>

		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
        
		<footer>
       
             
         <div class="wrap">
       
         <div class="email"></div>
		 
		 <br>
         <hr>
		 <br>
		 
         <div>

             <img class="w1" src="white1.png" alt="">
             <div class="abt"><br><br>
             <p class="footerp"> The Healthy Foodie Nutrition App<br>
                 is an interactive game that teaches  <br>
				 children the Basic Food Groups, which <br>
                 is the Go, Grow, and Glow Food, The <br>
                 Filipino Food Plate, and the Traffic <br>
                 Light Food Groups. <br>
             </p>
				
             </div>
         </div>
         <div>
              <img class="w2" src="white2.png" alt="">
              <div class="inf"><br><br>
              <ul>
                  <li><a href="">About Us</a></li>
                  <li><a href="">Pre Test</a></li>
                  <li><a href="">Post Test</a></li>
              </ul>
              </div>
         </div>
         <div>
              <img class="w3" src="WHITE3.png" alt="">
              <div class="serv"><br><br>
              <ul>
                  <li><a href="">Add Suggestions</a></li>
                  <li><a href="">Ask Developers</a></li>
                  <li><a href="">Request for Citation<br> of Resources</a></li>
              </ul>
              </div>
         </div>
         <div>
              <img class="w4" src="WHITE4.png" alt="">
              <div class="cnt"><br><br>
              <p class="footerp"> Contact the Administrator <br>or contact the client<br><br>
                  <!--Phone #:<br>-->Client: 836-8955<br>Admin: 836-8955<br>
                  Email. healthyfoodieweb@gmail.com
             </p>
             
              </div>
         </div>
        </div> 
         <div class="foot">
             <p class="foot1"> ©2018 The Healthy Foodie Nutrition Application. All rights reserved<p>
         </div>
    </footer>
    
    </body>
</html>
